package Progetto.GUI;

import Progetto.GUI.Controller.Controller;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * PaginaNuovoNatante è una classe che gestisce l'interfaccia grafica per l'inserimento di un nuovo natante.
 */
public class PaginaNuovoNatante extends JFrame{
    /**
     * JFrame per la finestra di inserimento di un nuovo natante.
     */
    public JFrame frameNuovoNatante;
    /**
     * Il controller utilizzato per interagire con la logica di business.
     */
    public Controller controller;
    private JPanel PanelNuovoNatante;
    private JButton buttonIndietro;
    private JPanel PanelTabella;
    private JTable tableNatanti;
    private JTextField codNatanteText;
    private JTextField capienzaAText;
    private JComboBox tipoNatanteCombo;
    private JTextField capienzaPText;
    private JButton inserisciNatante;
    private JLabel Messaggio;

    /**
     * Costruttore della classe PaginaNuovoNatante.
     *
     * @param controller        il controller per gestire le operazioni logiche
     * @param tabella           il frame della tabella principale
     * @param compagniaInserita la compagnia inserita
     */
    public PaginaNuovoNatante(Controller controller, JFrame tabella,String compagniaInserita) {
        this.controller = controller;
        frameNuovoNatante = new JFrame("Pagina Nuovo Natante");
        frameNuovoNatante.setContentPane(PanelNuovoNatante);
        frameNuovoNatante.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameNuovoNatante.pack();
        frameNuovoNatante.setVisible(true);
        frameNuovoNatante.setSize(800, 500);

        // Creazione del modello della tabella
        DefaultTableModel model = new DefaultTableModel(new Object[][]{}, new String[]{"CODICE NATANTE", "TIPO NATANTE", "CAPIENZAPASSEGGERI", "CAPIENZAAUTOMEZZI"}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableNatanti.setModel(model);
        tableNatanti.setRowHeight(50);
        PanelTabella.setLayout(new BorderLayout());
        PanelTabella.add(new JScrollPane(tableNatanti), BorderLayout.CENTER);

        String[] options = {"traghetto", "aliscafo", "motonave", "altro"};
        for (String option : options) {
            tipoNatanteCombo.addItem(option);
        }

        try {

            ArrayList<String[]> natanti = controller.stampaTabellaNatanti(compagniaInserita);
            aggiornaTabella(model, natanti);

        } catch(SQLException e) {
            throw new RuntimeException(e);
        }

        buttonIndietro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameNuovoNatante.setVisible(false);
                tabella.setVisible(true);
            }
        });

        inserisciNatante.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String codnat = codNatanteText.getText();
                String tiponat = (String)tipoNatanteCombo.getSelectedItem();
                Integer capienzaP = Integer.valueOf(capienzaPText.getText());
                Integer capienzaA = Integer.valueOf(capienzaAText.getText());

                try{
                    controller.inserimentoNatante(codnat, tiponat, compagniaInserita, capienzaP, capienzaA);
                    ArrayList<String[]> natanti = controller.stampaTabellaNatanti(compagniaInserita);
                    aggiornaTabella(model, natanti);
                    Messaggio.setText("Inserimento effettuato con successo.");
                } catch (SQLException ex){
                    throw new RuntimeException(ex);
                }
            }
        });
    }

    /**
     * Aggiorna la tabella dei natanti con i nuovi dati.
     *
     * @param model   il modello della tabella
     * @param natante l'elenco dei dati dei natanti
     */
    private void aggiornaTabella(DefaultTableModel model, ArrayList<String[]> natante) {
        model.setRowCount(0); // Rimuove tutte le righe attualmente presenti nel modello

        for (int i = 0; i < natante.size(); i++) {

            String[] rowData = natante.get(i);
            model.addRow(rowData);
        }
    }
}