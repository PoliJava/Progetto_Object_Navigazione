package Progetto.GUI;

import Progetto.GUI.Controller.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

/**
 * Questa classe gestisce la registrazione di un nuovo utente.
 */
public class RegistrazioneUtente extends JFrame{
    private JPanel registrazioneUtente;
    private JButton indietroButton;
    private JButton registratiButton;
    private JTextField nomeText;
    private JTextField cognomeText;
    private JComboBox <Integer> yearComboBox;
    private JComboBox <Integer> dayComboBox;
    private JComboBox <Integer> monthComboBox;
    private JPanel indietro;
    private JPanel nomeNuovo;
    private JPanel cognomeNuovo;
    private JPanel dataNascitaNuovo;
    private JPanel registrazione;
    private JLabel MessaggioAccesso;
    /**
     * Il frame per la registrazione dell'utente.
     */
    public static JFrame frame6 = new JFrame("Registrazione Utente");
    /**
     * Il controller che gestisce la logica dell'applicazione.
     */
    public Controller controller;

    /**
     * Istanzia un nuovo oggetto RegistrazioneUtente.
     *
     * @param controller     il controller per gestire la logica dell'applicazione
     * @param frameChiamante il frame chiamante
     */
    public RegistrazioneUtente(Controller controller, JFrame frameChiamante){

        this.controller = controller;
        frame6 = new JFrame("Pagina di accesso");
        frame6.setContentPane(registrazioneUtente);
        frame6.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame6.pack();
        frame6.setVisible(true);
        frame6.setSize(800, 500);

        Calendar cal = Calendar.getInstance();
        int currentYear = cal.get(Calendar.YEAR);
        for (int year = currentYear; year >= currentYear - 100; year--) {
            yearComboBox.addItem(year);
        }

        for (int month = 1; month <= 12; month++) {
            monthComboBox.addItem(month);
        }

        for (int day = 1; day <= 31; day++) {
            dayComboBox.addItem(day);
        }

        indietroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame6.setVisible(false);
                frameChiamante.setVisible(true);
            }
        });

        registratiButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String firstName = nomeText.getText();
                String lastName = cognomeText.getText();
                Date birthDate = getSelectedDate();

                try {

                    controller.creaUtente(firstName, lastName, birthDate);
                    int idPasseggero = controller.cercaIdPasseggero(firstName, lastName, birthDate);

                    PaginaUtenteIntero paginaUtenteIntero = new PaginaUtenteIntero(controller, frame6, idPasseggero);
                    frame6.setVisible(false);
                    paginaUtenteIntero.frame7.setVisible(true);

                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

    }

    /**
     * Ottiene la data di nascita selezionata dall'utente.
     *
     * @return la data di nascita selezionata
     */
    private Date getSelectedDate() {
        // Ottieni la data selezionata dalle JComboBox
        int year = (int) yearComboBox.getSelectedItem();
        int month = (int) monthComboBox.getSelectedItem();
        int day = (int) dayComboBox.getSelectedItem();

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month - 1); // I mesi in Java Calendar iniziano da 0
        cal.set(Calendar.DAY_OF_MONTH, day);

        return cal.getTime();
    }

    /**
     * Calcola l'età basata sulla data di nascita fornita.
     *
     * @param birthDate la data di nascita da cui calcolare l'età
     * @return l'età calcolata in anni
     */
    private int calculateAge(Date birthDate) {
        Calendar birthCalendar = Calendar.getInstance();
        birthCalendar.setTime(birthDate);
        Calendar now = Calendar.getInstance();

        int years = now.get(Calendar.YEAR) - birthCalendar.get(Calendar.YEAR);

        if (now.get(Calendar.DAY_OF_YEAR) < birthCalendar.get(Calendar.DAY_OF_YEAR)) {
            years--;
        }

        return years;
    }

}
