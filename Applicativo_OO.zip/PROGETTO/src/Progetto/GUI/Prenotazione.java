package Progetto.GUI;

import java.util.ArrayList;

/**
 * Rappresenta una prenotazione per un viaggio, che può includere più biglietti interi o ridotti.
 */
public class Prenotazione {
    /**
     * Indica se la prenotazione include l'utilizzo di un'auto.
     */
    public boolean auto;
    /**
     * Il peso del bagaglio associato alla prenotazione.
     */
    public float pesoBagaglio;
    /**
     * Il sovrapprezzo applicato alla prenotazione.
     */
    public float sovraPrezzoPrenotazione;
    /**
     * Il sovrapprezzo associato ai bagagli.
     */
    public float sovraPrezzoBagagli;
    /**
     * Il passeggero associato alla prenotazione.
     */
    Passeggero passeggero;
    /**
     * La corsa relativa alla prenotazione.
     */
    Corsa corsa;
    /**
     * La lista dei biglietti interi associati alla prenotazione.
     */
    ArrayList<BigliettoIntero> bigliettoI;
    /**
     * La lista dei biglietti ridotti associati alla prenotazione.
     */
    ArrayList<BigliettoRidotto> bigliettoR;

    /**
     * Costruisce una nuova prenotazione con i parametri specificati.
     *
     * @param auto                    indica se è inclusa l'utilizzo di un'auto
     * @param pesoBagaglio            il peso del bagaglio associato alla prenotazione
     * @param sovraPrezzoPrenotazione il sovrapprezzo applicato alla prenotazione
     * @param sovraPrezzoBagagli      il sovrapprezzo associato ai bagagli
     * @param p                       il passeggero associato alla prenotazione
     * @param c                       la corsa relativa alla prenotazione
     * @param bI                      il biglietto intero associato alla prenotazione
     * @param bR                      il biglietto ridotto associato alla prenotaazione
     */
    public Prenotazione(boolean auto, float pesoBagaglio, float sovraPrezzoPrenotazione,float sovraPrezzoBagagli,Passeggero p,Corsa c, BigliettoIntero bI, BigliettoRidotto bR)
    {
        this.auto = auto;
        this.pesoBagaglio = pesoBagaglio;
        this.sovraPrezzoPrenotazione=sovraPrezzoPrenotazione;
        this.sovraPrezzoBagagli=sovraPrezzoBagagli;
        passeggero = p;
        corsa = c;
        bigliettoI.add(bI);
        bigliettoR.add(bR);
    }
}
