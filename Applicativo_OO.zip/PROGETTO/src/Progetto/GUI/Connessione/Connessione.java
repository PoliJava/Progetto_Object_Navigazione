package Progetto.GUI.Connessione;


import Progetto.GUI.Principale;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Questa classe rappresenta la connessione tra il database e l'applicativo Java.
 */
public class Connessione{
    // ATTRIBUTI
    private static Connessione instance;
    /**
     * The Connection.
     */
    public Connection connection = null;
    private String nome = "postgres";
    private String password = "blackflowerblossom";
    private String url = "jdbc:postgresql://localhost:5432/Progetto";
    private String driver = "org.postgresql.Driver";

    // COSTRUTTORE
    /**
     * Costruttore privato che crea una connessione al database.
     *
     * @throws SQLException se si verifica un errore durante la connessione al database
     */
    private Connessione() throws SQLException {
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, nome, password);
            System.out.println("connessione riuscita");

        } catch (ClassNotFoundException ex) {
            System.out.println("Database Connection Creation Failed : " + ex.getMessage());
            ex.printStackTrace();
        }

    }


    /**
     * Gets instance: recupera l'istanza unica della classe Connessione
     *
     * @return l'istanza dela classe Connessione
     * @throws SQLException se si verifica un errore durante la creazione della connessione
     */
    public static Connessione getInstance() throws SQLException {

        // Se l'istanza è null o la connessione è chiusa, crea una nuova istanza
        if (instance == null || instance.connection.isClosed()) {
            instance = new Connessione();
        }
        return instance;
    }

    /**
     * Gets connection: ottiene la connessione al database.
     *
     * @return la conessione al database
     */
    public Connection getConnection() {
        return connection;
    }
}

