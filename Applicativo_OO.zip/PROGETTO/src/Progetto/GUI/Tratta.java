package Progetto.GUI;

import java.util.ArrayList;

/**
 * Rappresenta una tratta di viaggio tra due città, gestita da una compagnia di trasporti e che coinvolge
 * uno o più natanti in una o più corse.
 */
public class Tratta {

    /**
     * La città di partenza della tratta.
     */
    public String cittaPartenza;
    /**
     * La città di arrivo della tratta.
     */
    public String cittaArrivo;
    /**
     * Lo scalo o eventuali fermate intermedie della tratta.
     */
    public String scalo;
    /**
     * Il prezzo del biglietto per la tratta.
     */
    public float prezzo;
    /**
     * Le corse associate alla tratta.
     */
    ArrayList<Corsa> corsa;
    /**
     * Il giorno in cui si svolge la tratta.
     */
    Giorno giorno;
    /**
     * La compagnia che gestisce la tratta.
     */
    Compagnia compagnia;
    /**
     * I natanti coinvolti nella tratta.
     */
    ArrayList<Natante> natante;

    /**
     * Costruisce una nuova istanza di Tratta con i dati specificati.
     *
     * @param scalo   lo scalo o eventuali fermate intermedie della tratta
     * @param prezzo  il prezzo del biglietto per la tratta
     * @param g       il giorno in cui si svolge la tratta
     * @param comp    la compagnia che gestisce la tratta
     * @param n       il natante coinvolto nella tratta
     * @param portoP  la città di partenza della tratta
     * @param portoA  la città di arrivo della tratta
     */
    public Tratta(String scalo, float prezzo, Giorno g, Compagnia comp, Natante n, String portoP, String portoA) {
        this.scalo = scalo;
        this.prezzo = prezzo;
        this.cittaArrivo = portoA;
        this.cittaPartenza = portoP;
        giorno = g;
        compagnia = comp;
        natante.add(n);
    }
}
