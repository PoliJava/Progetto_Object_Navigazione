package Progetto.GUI.EsecuzioniQuery;
import Progetto.GUI.Connessione.Connessione;
import Progetto.GUI.DAO.Implementazioni;
import Progetto.GUI.PrenotazioneCorsa;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Classe che implementa l'interfaccia Implementazioni per l'accesso ai dati tramite database.
 */
public class ImplementazionePostgre implements Implementazioni {

    private Connection connection;

    /**
     * costruttore della classe ImplementazionePostgre.
     *
     * @throws SQLException se si verifica un errore durante l'apertura della connessione al database
     *
     */
    public ImplementazionePostgre() throws SQLException {
        try {
            //ottiene l'istanza della connessione al database
            connection = Connessione.getInstance().getConnection();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }



    }

    @Override
    public String verificaNome(String CompagniaInserita) throws SQLException {
        String query = "SELECT * FROM compagniadinavigazione WHERE nomecompagnia=? ";

        try (PreparedStatement leggiNome = connection.prepareStatement(query)) {
            leggiNome.setString(1, CompagniaInserita);

            try (ResultSet resultSet = leggiNome.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getString("nomecompagnia");
                } else {
                    return "Il nome non è presente nella tabella.";
                }
            }
        }
    }
    public void cercaPartenze(String CompagniaInserita, ArrayList<String> partenze)throws SQLException {
        String query = "SELECT cittapartenza FROM tratta WHERE nomecompagnia=? ORDER BY idtratta ASC";
        PreparedStatement cittaPartenza= connection.prepareStatement(query);
        cittaPartenza.setString(1, CompagniaInserita);
        ResultSet rs=cittaPartenza.executeQuery();
        while(rs.next())
        {
            partenze.add(rs.getString("cittapartenza"));
        }


    }
    public void cercaArrivo(String CompagniaInserita, ArrayList<String> arrivi)throws SQLException {
        String query = "SELECT cittaarrivo FROM tratta WHERE nomecompagnia=? ORDER BY idtratta ASC";
        PreparedStatement cittaarrivo= connection.prepareStatement(query);
        cittaarrivo.setString(1, CompagniaInserita);
        ResultSet rs=cittaarrivo.executeQuery();
        while(rs.next())
        {
            arrivi.add(rs.getString("cittaarrivo"));
        }


    }

    public void cercaScalo(String CompagniaInserita, ArrayList<String> scalo)throws SQLException {
        String query = "SELECT scalo FROM tratta WHERE nomecompagnia=? ORDER BY idtratta ASC";
        PreparedStatement scaloCompagnia= connection.prepareStatement(query);
        scaloCompagnia.setString(1, CompagniaInserita);
        ResultSet rs=scaloCompagnia.executeQuery();
        while(rs.next())
        {
            scalo.add(rs.getString("scalo"));
        }


    }

    public void cercaRitardo(String CompagniaInserita, ArrayList<String> ritardo)throws SQLException {
        String query = "SELECT ritardo FROM corsa NATURAL JOIN tratta WHERE nomecompagnia=? ORDER BY idcorsa ASC";
        PreparedStatement ritardoCompagnia= connection.prepareStatement(query);
        ritardoCompagnia.setString(1, CompagniaInserita);
        ResultSet rs=ritardoCompagnia.executeQuery();
        while(rs.next())
        {
            ritardo.add(rs.getString("ritardo"));
        }


    }
    public void cercaID(String CompagniaInserita, ArrayList<Integer> id)throws SQLException {
        String query = "SELECT idtratta FROM tratta WHERE nomecompagnia=? ORDER BY idtratta ASC";
        PreparedStatement idCompagnia= connection.prepareStatement(query);
        idCompagnia.setString(1, CompagniaInserita);
        ResultSet rs=idCompagnia.executeQuery();
        while(rs.next())
        {
            id.add(rs.getInt("idtratta"));
        }


    }

    public void modificareRitardo(int idCorsaInserito, String ritardoInserito) throws SQLException {
        String query = "UPDATE corsa SET ritardo = NULLIF(?, '') WHERE idcorsa = ? ";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, ritardoInserito);
            statement.setInt(2, idCorsaInserito);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Dati modificati correttamente nel database.");
            } else {
                System.out.println("Nessuna riga trovata con l'ID specificato.");
            }
        } catch (SQLException e) {
            System.out.println("Si è verificato un errore durante la modifica dei dati nel database: " + e.getMessage());
            throw e;
        }
    }



    public boolean verificaUtente(String nome, String cognome, Date dataNascita) throws SQLException {
        String query = "SELECT * FROM passeggero WHERE nome = ? AND cognome = ? AND datanascita = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, nome);
            statement.setString(2, cognome);
            statement.setDate(3, new java.sql.Date(dataNascita.getTime()));
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        }
    }

    public void creaUtente(String nome, String cognome, Date dataNascita) throws SQLException {
        String query = "INSERT INTO passeggero (nome, cognome, datanascita) VALUES (?, ?, ?)";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, nome);
        statement.setString(2, cognome);
        statement.setDate(3, new java.sql.Date(dataNascita.getTime()));
        statement.executeUpdate();
    }

    public void stampaTabella(String id, ArrayList<String> partenze, ArrayList<String> arrivi, ArrayList<String> scalo, ArrayList<String> ritardo) throws SQLException {
        String query = "SELECT cittapartenza,cittaarrivo,scalo,ritardo FROM tratta NATURAL JOIN corsa WHERE idcorsa LIKE ? ORDER BY idcorsa ASC";
        PreparedStatement cittaPartenza = connection.prepareStatement(query);
        cittaPartenza.setString(1, id);
        ResultSet rs = cittaPartenza.executeQuery();
        while (rs.next()) {
            partenze.add(rs.getString("cittapartenza"));
            arrivi.add(rs.getString("cittaarrivo"));
            scalo.add(rs.getString("scalo"));
            ritardo.add(rs.getString("ritardo"));

        }


    }

    public void stampaTabellaCompleta(ArrayList<String[]> resultData) throws SQLException {
        String query = "SELECT idcorsa, cittapartenza, cittaarrivo, scalo, ritardo, tiponatante, giorno, orariopartenza, prezzo, disponibilitapasseggero, disponibilitaauto " +
                "FROM corsa natural join cadenzagiornaliera natural join tratta natural join navigazione natural join natante ";

        PreparedStatement statement = connection.prepareStatement(query);
        ResultSet rs = statement.executeQuery();
        while(rs.next()) {
            String[] result = {rs.getString("idcorsa"), rs.getString("cittapartenza"), rs.getString("cittaarrivo"), rs.getString("scalo"), rs.getString("ritardo"), rs.getString("tiponatante"), rs.getString("giorno"), rs.getString("orariopartenza"), rs.getString("prezzo"), rs.getString("disponibilitapasseggero"), rs.getString("disponibilitaauto")};
            resultData.add(result);
        }
    }

    public void stampaTabellaCorse(String cittaPartenza, String cittaArrivo, String tipoNatante, Date giorno, Time orario, Double prezzo, ArrayList<String[]> resultData) throws SQLException {
        String query = "SELECT c1.idcorsa, t1.cittapartenza, t1.cittaarrivo, t1.scalo, c1.ritardo, n.tiponatante, c1.giorno, cg.orariopartenza, t1.prezzo, c1.disponibilitapasseggero, c1.disponibilitaauto " +
                "FROM corsa as c1 natural join cadenzagiornaliera as cg natural join tratta as t1 natural join navigazione natural join natante as n ";

        // Lista per memorizzare le condizioni WHERE
        List<String> conditions = new ArrayList<>();
        List<Object> parameters = new ArrayList<>();

        // Aggiungi condizioni per i filtri solo se i valori non sono nulli
        if (cittaPartenza != null && !cittaPartenza.isEmpty()) {
            conditions.add("cittapartenza = ?");
            parameters.add(cittaPartenza);
        }
        if (cittaArrivo != null && !cittaArrivo.isEmpty()) {
            conditions.add("cittaarrivo = ?");
            parameters.add(cittaArrivo);
        }
        if (tipoNatante != null && !tipoNatante.isEmpty()) {
            conditions.add("tiponatante = ?");
            parameters.add(tipoNatante);
        }

        if (giorno != null) {
            conditions.add("(giorno = ? OR (giorno = ?::date + 1 AND orariopartenza <= ?))");
            parameters.add(new java.sql.Date(giorno.getTime()));
            parameters.add(new java.sql.Date(giorno.getTime()));
            parameters.add(new java.sql.Time(orario.getTime())); // Aggiungi anche l'orario di partenza
        }

        if (prezzo != null) {
            conditions.add("t1.prezzo >= ?");
            parameters.add(prezzo);
        }

        // Costruisci la parte WHERE della query se sono presenti filtri
        if (!conditions.isEmpty()) {
            query += " WHERE " + String.join(" AND ", conditions);
        }

        // Aggiungi l'ordinamento alla query
        query += " ORDER BY giorno, orariopartenza ASC";

        PreparedStatement statement = connection.prepareStatement(query);

        // Imposta i parametri della PreparedStatement in base ai filtri applicati
        for (int i = 0; i < parameters.size(); i++) {
            Object parameter = parameters.get(i);
            if (parameter instanceof Date) {
                statement.setTimestamp(i + 1, new Timestamp(((Date) parameter).getTime()));
            } else if (parameter instanceof Time) {
                statement.setTimestamp(i + 1, new Timestamp(((Time) parameter).getTime()));
            } else {
                statement.setObject(i + 1, parameter);
            }
        }

        ResultSet rs = statement.executeQuery();
        while (rs.next()) {
            String[] result = {
                    rs.getString("idcorsa"),
                    rs.getString("cittapartenza"),
                    rs.getString("cittaarrivo"),
                    rs.getString("scalo"),
                    rs.getString("ritardo"),
                    rs.getString("tiponatante"),
                    rs.getString("giorno"),
                    rs.getString("orariopartenza"),
                    rs.getString("prezzo"),
                    rs.getString("disponibilitapasseggero"),
                    rs.getString("disponibilitaauto")
            };
            resultData.add(result);
        }
    }

    public void stampaTabellaCorseTratte(int idInserito,String CompagniaInserita,ArrayList<String[]> resultData) throws SQLException {
        String query = "SELECT idtratta,idcorsa,cittapartenza,cittaarrivo,ritardo,prezzo FROM tratta NATURAL JOIN corsa where idtratta=? AND nomecompagnia=?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, idInserito);
        statement.setString(2, CompagniaInserita);




        ResultSet rs = statement.executeQuery();
        while (rs.next()) {

            String[] result = {rs.getString("idtratta"), rs.getString("idcorsa"), rs.getString("cittapartenza"), rs.getString("cittaarrivo"), rs.getString("ritardo"),rs.getString("prezzo")};
            resultData.add(result);
        }

    }

    public void recuperoIDcorsa(int idInserito,String CompagniaInserita,ArrayList<String[]> resultData) throws SQLException {
        String query = "SELECT idcorsa FROM corsa NATURAL JOIN tratta where idtratta=? AND nomecompagnia=?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, idInserito);
        statement.setString(2, CompagniaInserita);


        ResultSet rs = statement.executeQuery();
        while (rs.next()) {

            String[] result = {rs.getString("idcorsa")};
            resultData.add(result);
        }
    }
    public void modificaScalo(int idInserito, String scaloInserito) throws SQLException {
        String query = "UPDATE tratta \n" +
                "SET scalo = NULLIF(?, '') \n" +
                "WHERE idtratta = ? ";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, scaloInserito);
            statement.setInt(2, idInserito);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Dati modificati correttamente nel database.");
            } else {
                System.out.println("Nessuna riga trovata con l'ID specificato.");
            }
        } catch (SQLException e) {
            System.out.println("Si è verificato un errore durante la modifica dei dati nel database: " + e.getMessage());
            throw e;
        }
    }

    public void creaCadenzaGiornaliera(Date datainizio,Date datafine, String giornosettimanale,Time orariopartenza,Time orarioarrivo,String nomecadenzagiornaliera ) throws SQLException {
        String query = "INSERT INTO cadenzagiornaliera (datainizio,datafine,giornosettimanale,orariopartenza,orarioarrivo,nomecadenzagiornaliera) VALUES (?, ?, ?,?,?,?)";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setDate(1, new java.sql.Date(datainizio.getTime()));
        statement.setDate(2, new java.sql.Date(datafine.getTime()));
        statement.setString(3,giornosettimanale);
        statement.setTime(4,new java.sql.Time(orariopartenza.getTime()));
        statement.setTime(5,new java.sql.Time(orarioarrivo.getTime()));
        statement.setString(6,nomecadenzagiornaliera);

        statement.executeUpdate();
    }

    public void creatratta(String cittaPartenza,String cittaArrivo,String scalo, String compagniaInserita,String nomeCadenzaGiornaliera,float prezzo ) throws SQLException {
        String query = "INSERT INTO tratta (cittapartenza,cittaarrivo,scalo,nomecompagnia,nomecadenzagiornaliera,prezzo) VALUES (?, ?, ?,?,?,?)";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1,cittaPartenza);
        statement.setString(2,cittaArrivo);
        statement.setString(3,scalo);
        statement.setString(4,compagniaInserita);
        statement.setString(5,nomeCadenzaGiornaliera);
        statement.setDouble(6, prezzo);



        statement.executeUpdate();
    }
    public int cercaIdPasseggero(String nome, String cognome, Date dataNascita) throws SQLException {
        String query = "SELECT idpasseggero FROM passeggero WHERE nome = ? AND cognome = ? AND datanascita = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, nome);
            statement.setString(2, cognome);
            statement.setDate(3, new java.sql.Date(dataNascita.getTime()));
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt("idpasseggero");
                } else {
                    return -1; // Utente non trovato
                }
            }
        }
    }

    public void creaPrenotazione(int idpasseggero, float pesoBagaglio, boolean auto, int idCorsa) throws SQLException {
        String query = "INSERT INTO PRENOTAZIONE (idpasseggero, peso_bagaglio, auto, idcorsa) VALUES (?, ?, ?, ?)";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1,idpasseggero);
        statement.setFloat(2, pesoBagaglio);
        statement.setBoolean(3, auto);
        statement.setInt(4, idCorsa);
        statement.executeUpdate();
    }

    public void stampaTabellaPrenotazioniIntero(Integer idpasseggero, ArrayList<String[]> resultData) throws SQLException {
        String query = "select distinct pre1.idprenotazione, b1.nominativo, t1.cittapartenza, t1.cittaarrivo, t1.scalo, c1.ritardo, pre1.auto, c1.giorno, cg1.orariopartenza, cg1.orarioarrivo, b1.prezzo, b1.codbigliettoi\n" +
                "from cadenzagiornaliera as cg1\n" +
                "join tratta as t1 on cg1.nomecadenzagiornaliera = t1.nomecadenzagiornaliera\n" +
                "join corsa as c1 on t1.idtratta = c1.idtratta\n" +
                "join prenotazione as pre1 on c1.idcorsa = pre1.idcorsa\n" +
                "join bigliettointero as b1 on pre1.idprenotazione = b1.idprenotazione\n" +
                "where pre1.idpasseggero = ?";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, idpasseggero);
        ResultSet rs = statement.executeQuery();
        while(rs.next()) {
            String[] result = {rs.getString("idprenotazione"), rs.getString("nominativo"), rs.getString("cittapartenza"), rs.getString("cittaarrivo"), rs.getString("scalo"), rs.getString("ritardo"), rs.getString("auto"), rs.getString("giorno"), rs.getString("orariopartenza"), rs.getString("orarioarrivo"), rs.getString("prezzo"), rs.getString("codbigliettoi")};
            resultData.add(result);
        }
    }

    public void stampaTabellaPrenotazioniRidotto(Integer idpasseggero, ArrayList<String[]> resultData) throws SQLException {
        String query = "select distinct pre1.idprenotazione, b1.nominativo, t1.cittapartenza, t1.cittaarrivo, t1.scalo, c1.ritardo, pre1.auto, c1.giorno, cg1.orariopartenza, cg1.orarioarrivo, b1.prezzo, b1.codbigliettor\n" +
                "from cadenzagiornaliera as cg1\n" +
                "join tratta as t1 on cg1.nomecadenzagiornaliera = t1.nomecadenzagiornaliera\n" +
                "join corsa as c1 on t1.idtratta = c1.idtratta\n" +
                "join prenotazione as pre1 on c1.idcorsa = pre1.idcorsa\n" +
                "join bigliettoridotto as b1 on pre1.idprenotazione = b1.idprenotazione\n" +
                "where pre1.idpasseggero = ?";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, idpasseggero);
        ResultSet rs = statement.executeQuery();
        while(rs.next()) {
            String[] result = {rs.getString("idprenotazione"), rs.getString("nominativo"), rs.getString("cittapartenza"), rs.getString("cittaarrivo"), rs.getString("scalo"), rs.getString("ritardo"), rs.getString("auto"), rs.getString("giorno"), rs.getString("orariopartenza"), rs.getString("orarioarrivo"), rs.getString("prezzo"), rs.getString("codbigliettor")};
            resultData.add(result);
        }
    }

    public Date recuperaDataNascita(Integer idpasseggero) throws SQLException{

        String query = "Select datanascita from passeggero where idpasseggero = ?";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1,idpasseggero);

        try (ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                return resultSet.getDate("datanascita");
            }
        }
        return null;
    }

    public void eliminaPrenotazioneIntero (int idprenotazione, int idpasseggero) throws SQLException {

        String query = "DELETE FROM bigliettointero WHERE idprenotazione = ? and idpasseggero = ?";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, idprenotazione);
        statement.setInt(2, idpasseggero);
        statement.executeUpdate();
    }
    public void eliminaPrenotazioneRidotto (int idprenotazione, int idpasseggero) throws SQLException {

        String query = "DELETE FROM bigliettoridotto WHERE idprenotazione = ? and idpasseggero = ?";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, idprenotazione);
        statement.setInt(2, idpasseggero);
        statement.executeUpdate();
    }

    public String recuperaTelefonoCompagnia(String compagnia) throws SQLException {
        String query = "SELECT telefono FROM compagniadinavigazione WHERE nomecompagnia = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, compagnia);
        try (ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                return resultSet.getString("telefono");
            }
        }
        return null;
    }

    public String recuperaEmailCompagnia(String compagnia) throws SQLException{
        String query = "SELECT mail FROM compagniadinavigazione WHERE nomecompagnia = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, compagnia);
        try(ResultSet rs = statement.executeQuery()) {
            if(rs.next()) {
                return rs.getString("mail");
            }
        }
        return null;
    }

    public String recuperaSitoWeb(String compagnia) throws SQLException{
        String query = "SELECT sitoweb FROM compagniadinavigazione WHERE nomecompagnia = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, compagnia);
        try(ResultSet rs = statement.executeQuery()) {
            if(rs.next()) {
                return rs.getString("sitoweb");
            }
        }
        return null;
    }

    public ArrayList<String> recuperaIndirizziSocial (String compagnia) throws SQLException{

        ArrayList<String> indirizziSocial = new ArrayList<>();
        String query = "SELECT indirizzo FROM indirizzosocial WHERE nomecompagnia = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, compagnia);
        try(ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                String indirizzo = rs.getString("indirizzo");
                indirizziSocial.add(indirizzo);
            }
        }
        return indirizziSocial;

    }

    public String recuperaCompagnia(Integer idcorsa) throws SQLException{
        String query = "select nomecompagnia from corsa as c1 natural join tratta as t1\n" +
                "where c1.idtratta = t1.idtratta and c1.idcorsa = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, idcorsa);
        try(ResultSet rs = statement.executeQuery()) {
            if(rs.next()) {
                return rs.getString("nomecompagnia");
            }
        }
        return null;
    }

    public void stampaTabellaNatanti(String nomeCompagnia, ArrayList<String[]> resultData) throws SQLException{

        String query = "SELECT codNatante, tiponatante, capienzapasseggeri, capienzaautomezzi FROM natante WHERE nomecompagnia = ?";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, nomeCompagnia);

        ResultSet rs = statement.executeQuery();
        while (rs.next()) {

            String[] result = {rs.getString("codnatante"), rs.getString("tiponatante"), rs.getString("capienzapasseggeri"), rs.getString("capienzaautomezzi")};
            resultData.add(result);
        }
    }

    public void inserimentoNatante(String codnatante, String tipoNatante, String nomeCompagnia, Integer capienzaP, Integer capienzaA) throws SQLException {
        String query = "INSERT INTO natante VALUES (?, ?, ?, ?, ?)";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1,codnatante);
        statement.setString(2, nomeCompagnia);
        statement.setString(3, tipoNatante);
        statement.setInt(4, capienzaP);
        statement.setInt(5, capienzaA);

        statement.executeUpdate();
    }

    public void cercaNatante(String compagniaInserita, ArrayList<String> natanti) throws SQLException {
        String query = "SELECT codnatante FROM tratta NATURAL JOIN navigazione WHERE nomecompagnia = ? ORDER BY idtratta ASC";
        PreparedStatement statement= connection.prepareStatement(query);
        statement.setString(1, compagniaInserita);
        ResultSet rs=statement.executeQuery();
        while(rs.next())
        {
            natanti.add(rs.getString("codnatante"));
        }
    }
}





