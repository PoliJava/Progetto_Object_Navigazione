package Progetto.GUI;

import java.sql.Time;
import java.util.Date;
import java.util.ArrayList;

/**
 * Rappresenta un giorno specifico in cui vengono effettuate corse su determinate tratte.
 */
public class Giorno {
    /**
     * La data di inizio validità del giorno.
     */
    public Date dataInizio;
    /**
     * La data di fine validità del giorno.
     */
    public Date dataFine;
    /**
     * Il giorno della settimana relativo a questo giorno.
     */
    public String giornoSettimanale;
    /**
     * L'orario di partenza delle corse in questo giorno.
     */
    public Time orarioPartenza;
    /**
     * L'orario di arrivo delle corse in questo giorno.
     */
    public Time orarioArrivo;

    /**
     * La lista delle tratte programmate per questo giorno.
     */
    ArrayList<Tratta> tratta;

    /**
     * Costruisce una nuova istanza di Giorno con i parametri specificati.
     *
     * @param dataInizio        la data di inizio validità del giorno
     * @param dataFine          la data di fine validità del giorno
     * @param giornoSettimanale il giorno della settimana relativo a questo giorno
     * @param orarioPartenza    l'orario di partenza delle corse in questo giorno
     * @param orarioArrivo      l'orario di arrivo delle corse in questo giorno
     * @param t                 la tratta associata a questo giorno
     */
    public Giorno(Date dataInizio, Date dataFine, String giornoSettimanale, Time orarioPartenza, Time orarioArrivo, Tratta t) {
        this.dataInizio = dataInizio;
        this.dataFine = dataFine;
        this.giornoSettimanale = giornoSettimanale;
        this.orarioPartenza = orarioPartenza;
        this.orarioArrivo = orarioArrivo;
        tratta.add(t);
    }
}
