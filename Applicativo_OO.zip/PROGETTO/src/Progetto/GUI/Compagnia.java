package Progetto.GUI;

import java.util.ArrayList;

/**
 * Rappresenta una compagnia di trasporti, che gestisce natanti, tratte e informazioni di contatto.
 */
public class Compagnia {
    /**
     * Il nome della compagnia.
     */
    public String nome;
    /**
     * Il numero di natanti disponibili presso la compagnia.
     */
    public int natantiDisponibili;
    /**
     * Il numero di telefono della compagnia.
     */
    public String telefono;
    /**
     * L'indirizzo email della compagnia.
     */
    public String mail;
    /**
     * Il sito web della compagnia.
     */
    public String sitoWeb;

    /**
     * La lista delle tratte gestite dalla compagnia.
     */
    ArrayList<Tratta> tratta;
    /**
     * La lista dei natanti gestiti dalla compagnia.
     */
    ArrayList<Natante> natante;
    /**
     * La lista degli indirizzi social associati alla compagnia.
     */
    ArrayList<IndirizzoSocial> indirizzoSocial;

    /**
     * Costruisce una nuova compagnia con i parametri specificati.
     *
     * @param nome               il nome della compagnia
     * @param natantiDisponibili il numero di natanti disponibili
     * @param telefono           il numero di telefono della compagnia
     * @param mail               l'indirizzo email della compagnia
     * @param sitoWeb            il sito web della compagnia
     * @param n                  il natante associato alla compagnia
     * @param indirizzoS         l'indirizzo social associato alla compagnia
     * @param t                  la tratta gestita dalla compagnia
     */
    public Compagnia(String nome, int natantiDisponibili, String telefono, String mail, String sitoWeb, Natante n, IndirizzoSocial indirizzoS, Tratta t)
    {
        this.nome = nome;
        this.natantiDisponibili = natantiDisponibili;
        this.telefono = telefono;
        this.mail = mail;
        this.sitoWeb = sitoWeb;
        natante.add(n);
        indirizzoSocial.add(indirizzoS);
        tratta.add(t);
    }
}
