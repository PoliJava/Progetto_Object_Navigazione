package Progetto.GUI.DAO;

import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;

/**
 * Interfaccia che definisce le implementazioni di accesso ai dati per il progetto.
 */
public interface Implementazioni {
    /**
     * verifica se il nome della compagnia è presente nel database.
     *
     * @param compagniaInserita nome della compagnia da verificare
     * @return stringa che rappresenta il risultato della verifica
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public String verificaNome(String compagniaInserita) throws SQLException;

    /**
     * Cerca le partenze per una compagnia specifica.
     *
     * @param compagniaInserita il nome della compagnia di cui cercare le partenze
     * @param partenze una lista in cui memorizzare le partenze trovate
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void cercaPartenze(String compagniaInserita, ArrayList<String> partenze) throws SQLException;

    /**
     * Cerca gli arrivi per una compagnia specifica.
     *
     * @param compagniaInserita il nome della compagnia di cui cercare gli arrivi
     * @param arrivi una lista in cui memorizzare gli arrivi trovati
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void cercaArrivo(String compagniaInserita, ArrayList<String> arrivi) throws SQLException;

    /**
     * Cerca gli scali per una compagnia specifica.
     *
     * @param compagniaInserita il nome della compagnia di cui cercare gli scali
     * @param scalo una lista in cui memorizzare gli scali trovati
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void cercaScalo(String compagniaInserita, ArrayList<String> scalo) throws SQLException;

    /**
     * Cerca gli ID per una compagnia specifica.
     *
     * @param compagniaInserita il nome della compagnia di cui cercare gli ID
     * @param id una lista in cui memorizzare gli ID trovati
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void cercaID(String compagniaInserita, ArrayList<Integer> id) throws SQLException;

    /**
     * Verifica se un utente è presente nel database.
     *
     * @param nome il nome dell'utente da verificare
     * @param cognome il cognome dell'utente da verificare
     * @param dataNascita la data di nascita dell'utente da verificare
     * @return true se l'utente è presente nel database, altrimenti false
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public boolean verificaUtente(String nome, String cognome, Date dataNascita) throws SQLException;

    /**
     * Modifica il ritardo di una corsa.
     *
     * @param idCorsaInserito l'ID della corsa da modificare
     * @param ritardoInserito il ritardo da inserire
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void modificareRitardo(int idCorsaInserito, String ritardoInserito) throws SQLException;

    /**
     * Crea un nuovo passeggero nel database.
     *
     * @param nome il nome dell'utente da creare
     * @param cognome il cognome dell'utente da creare
     * @param dataNascita la data di nascita dell'utente da creare
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void creaUtente(String nome, String cognome, Date dataNascita) throws SQLException;

    /**
     * Stampa la tabella delle corse in base ai criteri specificati.
     *
     * @param cittaPartenza la città di partenza delle corse da cercare
     * @param cittaArrivo la città di arrivo delle corse da cercare
     * @param tipoNatante il tipo di natante delle corse da cercare
     * @param giorno il giorno delle corse da cercare
     * @param orario l'orario delle corse da cercare
     * @param prezzo il prezzo delle corse da cercare
     * @param resultData una lista in cui memorizzare i dati delle corse trovate
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void stampaTabellaCorse(String cittaPartenza, String cittaArrivo, String tipoNatante, Date giorno, Time orario, Double prezzo, ArrayList<String[]> resultData) throws SQLException;

     /**
     * Stampa la tabella completa dei dati.
     *
     * @param resultData i dati da stampare
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void stampaTabellaCompleta(ArrayList<String[]> resultData) throws SQLException;

    /**
     * Stampa la tabella delle corse per una tratta specifica.
     *
     * @param idInserito l'ID della tratta
     * @param compagniaInserita il nome della compagnia della tratta
     * @param resultData i dati da stampare
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void stampaTabellaCorseTratte(int idInserito,String compagniaInserita,ArrayList<String[]> resultData) throws SQLException;

    /**
     * Recupera l'ID di una corsa.
     *
     * @param idInserito l'ID della corsa
     * @param compagniaInserita il nome della compagnia della corsa
     * @param resultData i dati da memorizzare
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void recuperoIDcorsa(int idInserito,String compagniaInserita,ArrayList<String[]> resultData) throws SQLException;

    /**
     * Modifica lo scalo di una corsa.
     *
     * @param idInserito l'ID della corsa da modificare
     * @param scaloInserito lo scalo da inserire
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void modificaScalo(int idInserito, String scaloInserito) throws SQLException;

    /**
     * Crea una cadenza giornaliera per le tratte.
     *
     * @param datainizio la data di inizio della cadenza
     * @param datafine la data di fine della cadenza
     * @param giornosettimanale il giorno settimanale della cadenza
     * @param orariopartenza l'orario di partenza della corsa
     * @param orarioarrivo l'orario di arrivo della corsa
     * @param nomecadenzagiornaliera il nome della cadenza giornaliera
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void creaCadenzaGiornaliera(Date datainizio,Date datafine, String giornosettimanale,Time orariopartenza,Time orarioarrivo,String nomecadenzagiornaliera ) throws SQLException;

    /**
     * Crea una tratta per la compagnia di navigazione che sta utilizzando il programma.
     *
     * @param cittaPartenza la città di partenza della tratta
     * @param cittaArrivo la città di arrivo della tratta
     * @param scalo lo scalo della tratta
     * @param compagniaInserita il nome della compagnia della tratta
     * @param nomeCadenzaGiornaliera il nome della cadenza giornaliera della tratta
     * @param prezzo il prezzo della tratta
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void creatratta(String cittaPartenza,String cittaArrivo,String scalo, String compagniaInserita,String nomeCadenzaGiornaliera,float prezzo ) throws SQLException;

    /**
     * Cerca l'id del passeggero che ha effettuato l'accesso.
     *
     * @param nome        nome del passeggero
     * @param cognome     cognome del passeggero
     * @param dataNascita data di nascita del passeggero
     * @return l'id del passeggero trovato
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public int cercaIdPasseggero(String nome, String cognome, Date dataNascita) throws SQLException;

    /**
     * Crea una prenotazione per il passeggero che sta acquistando un biglietto per la corsa.
     *
     * @param idpasseggero id del passeggero
     * @param pesoBagaglio peso del bagaglio da inserire per calcolare il sovrapprezzo
     * @param auto         auto, per decidere se si vuole portarla o meno
     * @param idCorsa      id della corsa che si sta prenotando
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void creaPrenotazione(int idpasseggero, float pesoBagaglio, boolean auto, int idCorsa) throws SQLException;

    /**
     * Stampa la tabella delle prenotazioni per utenti che rientrano nei costi interi del biglietto.
     *
     * @param idpasseggero id del passeggero
     * @param resultData   restituisce tutte le tuple con i dati risultanti dalla query
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void stampaTabellaPrenotazioniIntero(Integer idpasseggero, ArrayList<String[]> resultData) throws SQLException;

    /**
     * Stampa la tabella delle prenotazioni per utenti che rientrano nei costi ridotti del biglietto.
     *
     * @param idpasseggero id del passeggero
     * @param resultData   restituisce tutte le tuple con i dati risultanti dalla query
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void stampaTabellaPrenotazioniRidotto(Integer idpasseggero, ArrayList<String[]> resultData) throws SQLException;

    /**
     * Recupera la data di nascita che servirà per calcolare l'età del passeggero.
     *
     * @param idpasseggero id del passeggero di cui si cerca la data di nascita
     * @return il valore risultante
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public Date recuperaDataNascita(Integer idpasseggero) throws SQLException;

    /**
     * Elimina la prenotazione dal database per l'utente che ha acquistato un biglietto intero.
     *
     * @param idprenotazione id della prenotazione da eliminare
     * @param idpasseggero   id del passeggero che elimina la prenotazione
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void eliminaPrenotazioneIntero (int idprenotazione, int idpasseggero) throws SQLException;

    /**
     * Elimina la prenotazione dal database per l'utente che ha acquistato un biglietto ridotto.
     *
     * @param idprenotazione id della prenotazione da eliminare
     * @param idpasseggero   id del passeggero che elimina la prenotazione
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void eliminaPrenotazioneRidotto (int idprenotazione, int idpasseggero) throws SQLException;

    /**
     * Recupera il numemro di telefono della compagnia.
     *
     * @param compagnia compagnia di navigazione di cui si vuole recuperare il numero
     * @return il valore risultante
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public String recuperaTelefonoCompagnia(String compagnia) throws SQLException;

    /**
     * Recupera l'indirizzo email della compagnia.
     *
     * @param compagnia compagnia di navigazione di cui si vuole recuperare l'indirizzo mail
     * @return valore risultante
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public String recuperaEmailCompagnia(String compagnia) throws SQLException;

    /**
     * Recupera il sito web della compagnia.
     *
     * @param compagnia compagnia di navigazione di cui si vuole recuperare il sito web
     * @return valore risultante
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public String recuperaSitoWeb(String compagnia) throws SQLException;

    /**
     * Recupera gli indirizzi social della compagnia.
     *
     * @param compagnia compagnia di navigazione
     * @return arrayList dei valori risultanti
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public ArrayList<String>  recuperaIndirizziSocial (String compagnia) throws SQLException;

    /**
     * Recupera il nome della compagnia di navigazione.
     *
     * @param idcorsa id della corsa per cui si sta cercando il nome della compagnia
     * @return valore risultante
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public String recuperaCompagnia(Integer idcorsa) throws SQLException;

    /**
     * Stampa la tabella dei natanti per la compagnia di navigazione specificata.
     *
     * @param nomeCompagnia nome della compagnia
     * @param resultData    risultato dove sono memorizzati tutti i natanti della compagnia
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void stampaTabellaNatanti(String nomeCompagnia, ArrayList<String[]> resultData) throws SQLException;

    /**
     * Inserisce una tupla nella relazione natante in base al nome della compagnia.
     *
     * @param codnatante    codice del natante
     * @param tipoNatante   tipo del natante
     * @param nomeCompagnia nome della compagnia
     * @param capienzaP     capienza passeggeri
     * @param capienzaA     capienza automezzi
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void inserimentoNatante(String codnatante, String tipoNatante, String nomeCompagnia, Integer capienzaP, Integer capienzaA) throws SQLException;

    /**
     * Cerca il codice del natante per associarlo alla tratta.
     *
     * @param compagniaInserita compagnia di navigazione
     * @param natanti           natanti memorizzati
     * @throws SQLException se si verifica un errore SQL durante l'operazione
     */
    public void cercaNatante(String compagniaInserita, ArrayList<String> natanti) throws SQLException;


    }