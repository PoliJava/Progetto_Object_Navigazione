package Progetto.GUI;

import Progetto.GUI.Controller.Controller;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Rappresenta la pagina delle corse per una specifica tratta di una compagnia.
 */
public class PaginaCorse {
    private JPanel homeCorsa;
    private JButton TornaATratte;
    private JTextField inserimentoIDCorsa;
    private JTable tabellaCorsa;
    private JPanel panelTabella;
    private JButton INVIAButton;
    private JTextField modificaRitardi;
    private JButton modificaButton;
    private JLabel messaggioDiConferma;
    private JPanel panelModifica;
    /**
     * Il frame per la pagina delle corse.
     */
    public JFrame frameCorsa;
    /**
     * Il controller per gestire le azioni delle corse.
     */
    public Controller controller;


    /**
     * Costruisce una nuova istanza di PaginaCorse.
     *
     * @param controller        il controller per gestire le azioni delle corse
     * @param Tabella           il frame della tabella delle tratte
     * @param idInserito        l'ID della tratta selezionata
     * @param CompagniaInserita il nome della compagnia selezionata
     * @param MessaggioAccesso  il messaggio di accesso
     */
    public PaginaCorse(Controller controller, JFrame Tabella, int idInserito,String CompagniaInserita,JLabel MessaggioAccesso) {
        this.controller=controller;
        frameCorsa = new JFrame("Pagina Corsa");
        frameCorsa.setContentPane(homeCorsa);
        frameCorsa.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameCorsa.pack();
        frameCorsa.setVisible(true);
        frameCorsa.setSize(800, 500);
        panelModifica.setVisible(false);

        DefaultTableModel model = new DefaultTableModel(new Object[][]{}, new String[]{"ID TRATTA","ID CORSA","PARTENZA", "ARRIVI","RITARDI","PREZZO"}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tabellaCorsa.setModel(model);
        tabellaCorsa.setRowHeight(50);
        panelTabella.setLayout(new BorderLayout());
        panelTabella.add(new JScrollPane(tabellaCorsa), BorderLayout.CENTER);

        try {

            ArrayList<String[]> corseComplete = controller.stampaTabellaCorseTratte(idInserito,CompagniaInserita);
            aggiornaTabella(model, corseComplete);

        } catch(SQLException e) {
            throw new RuntimeException(e);
        }

        TornaATratte.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                frameCorsa.setVisible(false);
                Tabella.setVisible(true);
                MessaggioAccesso.setText(" ");

            }


        });

        INVIAButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    ArrayList<String[]> idcorsa = controller.recuperoIDcorsa(idInserito,CompagniaInserita);
                    ArrayList<String[]> corseComplete = controller.stampaTabellaCorseTratte(idInserito,CompagniaInserita);
                    aggiornaTabella(model, corseComplete);
                    for (int i = 0; i < idcorsa.size(); i++) {
                        String[] id = idcorsa.get(i);
                        int idCorrente = Integer.parseInt(id[0]);

                        if ( Integer.parseInt(inserimentoIDCorsa.getText())==idCorrente) {
                            panelModifica.setVisible(true);
                            break;
                        }
                        else
                        {
                            panelModifica.setVisible(false);
                        }
                    }
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }

            }
        });

        modificaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int idcorsaInserito = Integer.parseInt(inserimentoIDCorsa.getText().trim());
                    String nuovoRitardo = modificaRitardi.getText().trim();

                    ArrayList<String[]> corseComplete = controller.stampaTabellaCorseTratte(idInserito,CompagniaInserita);
                    aggiornaTabella(model, corseComplete);

                    if (!nuovoRitardo.isEmpty()) {
                        controller.modificareRitardo(idcorsaInserito, nuovoRitardo);
                        corseComplete = controller.stampaTabellaCorseTratte(idInserito,CompagniaInserita);
                        aggiornaTabella(model, corseComplete);

                        messaggioDiConferma.setText("Modifica effettuata con successo!");
                    } else {
                        messaggioDiConferma.setText("Inserisci un valore per il ritardo!");
                    }

                    modificaButton.setEnabled(true);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
    }

    /**
     * Aggiorna la tabella delle corse.
     *
     * @param model il modello della tabella
     * @param corsa l'elenco delle corse da visualizzare
     */
    private void aggiornaTabella(DefaultTableModel model, ArrayList<String[]> corsa) {
        model.setRowCount(0); // Rimuove tutte le righe attualmente presenti nel modello
        int indiceRitardo = 4;



        for (int i = 0; i < corsa.size(); i++) {
            String[] primaRiga = corsa.get(i);
            String ritardo = primaRiga[indiceRitardo];
            if (ritardo == null || ritardo.isEmpty() || ritardo.equals("null")) {
                primaRiga[indiceRitardo] = "Nessun ritardo";
            }
            String[] rowData = corsa.get(i);
            model.addRow(rowData);
        }

    }

}

