package Progetto.GUI;

import java.util.ArrayList;
import java.util.Date;

/**
 * Rappresenta una singola corsa effettuata da una compagnia su una tratta specifica.
 */
public class Corsa {

    /**
     * La disponibilità di posti passeggero sulla corsa.
     */
    public int disponibilitaPasseggero;
    /**
     * La disponibilità di spazi per auto sulla corsa.
     */
    public int disponibilitaAuto;
    /**
     * Il giorno in cui si svolge la corsa.
     */
    Date giornoCorsa;
    /**
     * Eventuale ritardo della corsa.
     */
    public String ritardo;
    /**
     * Lista delle prenotazioni effettuate per questa corsa.
     */
    ArrayList<Prenotazione> prenotazione;

    /**
     * La tratta associata a questa corsa.
     */
    Tratta tratta;

    /**
     * Costruisce una nuova istanza di Corsa con i parametri specificati.
     *
     * @param disponibilitaPasseggero la disponibilità di posti passeggero sulla corsa
     * @param disponibilitaAuto       la disponibilità di spazi per auto sulla corsa
     * @param ritardo                 l'eventuale ritardo della corsa
     * @param giornoCorsa             il giorno in cui si svolge la corsa
     * @param t                       la tratta associata a questa corsa
     * @param pren                    la prenotazione relativa a questa corsa
     */
    public Corsa(int disponibilitaPasseggero, int disponibilitaAuto, String ritardo, Date giornoCorsa, Tratta t, Prenotazione pren)
    {
        this.disponibilitaPasseggero = disponibilitaPasseggero;
        this.disponibilitaAuto = disponibilitaAuto;
        this.ritardo=ritardo;
        this.giornoCorsa = giornoCorsa;
        tratta = t;
        prenotazione.add(pren);
    }

}
