package Progetto.GUI;

import Progetto.GUI.Controller.Controller;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.*;

/**
 * La classe rappresenta una finestra per la visualizzazione delle prenotazioni effettuate dall'utente.
 */
public class VisualizzaPrenotazioni extends JFrame{
    private JTable tablePrenotazioni;
    private JButton cancellaPrenotazioneButton;
    private JLabel MessaggioCancellazione;
    private JPanel prenotazioni;
    private JPanel PanelTabella;
    private JButton indietroButton;
    private JPanel contatti;
    private JLabel contattiCompagniaLabel;
    private JLabel indirizziSocialLabel;
    private JLabel sitoWebLabel;
    private JLabel mailLabel;
    private JLabel telefonoLabel;
    /**
     * Il frame per la visualizzazione delle prenotazioni.
     */
    public JFrame frameVisualizzaPrenotazioni = new JFrame("Prenotazioni effettuate");
    /**
     * Il controller per la gestione delle operazioni logiche.
     */
    public Controller controller;
    /**
     * Il frame chiamante da cui è stata aperta questa finestra.
     */
    public JFrame frameChiamante;

    /**
     * Costruisce una nuova istanza della finestra per la visualizzazione delle prenotazioni.
     *
     * @param controller     Il controller per la gestione delle operazioni logiche
     * @param frameChiamante Il frame chiamante da cui è stata aperta questa finestra
     * @param idPasseggero   L'ID dell'utente per il quale visualizzare le prenotazioni
     */
    public VisualizzaPrenotazioni(Controller controller, JFrame frameChiamante, int idPasseggero) {
        this.controller = controller;
        frameVisualizzaPrenotazioni = new JFrame("Pagina Utente");
        frameVisualizzaPrenotazioni.setContentPane(prenotazioni);
        frameVisualizzaPrenotazioni.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameVisualizzaPrenotazioni.pack();
        frameVisualizzaPrenotazioni.setVisible(true);
        frameVisualizzaPrenotazioni.setSize(800, 500);

        DefaultTableModel model = new DefaultTableModel(new Object[][]{}, new String[]{
                "IDPRENOTAZIONE", "NOMINATIVO", "CITTA PARTENZA", "CITTA ARRIVO", "SCALO", "RITARDO", "AUTO", "DATA", "ORA PARTENZA", "ORA ARRIVO", "PREZZO BIGLIETTO", "CODICE BIGLIETTO"
        }) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tablePrenotazioni.setModel(model);
        tablePrenotazioni.setRowHeight(50);
        PanelTabella.setLayout(new BorderLayout());
        PanelTabella.add(new JScrollPane(tablePrenotazioni), BorderLayout.CENTER);

        try{

            Date datanascita = controller.cercaDataNascita(idPasseggero);
            int etaPasseggero = calculateAge(datanascita);

            if (etaPasseggero >= 18) {
                ArrayList<String[]> prenotazioniIntero = controller.stampaTabellaPrenotazioniIntero(idPasseggero);
                aggiornaTabella(model, prenotazioniIntero);
            } else {
                ArrayList<String[]> prenotazioniRidotto = controller.stampaTabellaPrenotazioniRidotto(idPasseggero);
                aggiornaTabella(model, prenotazioniRidotto);
            }

        } catch (SQLException ex){
            throw new RuntimeException(ex);
        }

        indietroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameVisualizzaPrenotazioni.setVisible(false);
                frameChiamante.setVisible(true);
            }
        });

        cancellaPrenotazioneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int selectedRow = tablePrenotazioni.getSelectedRow();
                if (selectedRow != -1) {

                    DefaultTableModel model = (DefaultTableModel) tablePrenotazioni.getModel();
                    try{
                        Date datanascita = controller.cercaDataNascita(idPasseggero);
                        int etaPasseggero = calculateAge(datanascita);
                        int idprenotazione = Integer.parseInt((String) tablePrenotazioni.getValueAt(selectedRow, 0));

                        try {

                            if (etaPasseggero >= 18) {
                                controller.eliminaPrenotazioneIntero(idprenotazione, idPasseggero);
                                model.removeRow(selectedRow);
                            } else {
                                controller.eliminaPrenotazioneRidotto(idprenotazione, idPasseggero);
                                model.removeRow(selectedRow);
                            }
                        } catch (SQLException ex) {
                            throw new RuntimeException(ex);
                        }
                    } catch (SQLException ex1){
                        throw new RuntimeException(ex1);
                    }
                    MessaggioCancellazione.setText("Prenotazione eliminata con successo.");
                } else {
                    MessaggioCancellazione.setText("Nessuna riga selezionata.");
                }
            }
        });

        tablePrenotazioni.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if(!e.getValueIsAdjusting()) {
                    int selectedRow = tablePrenotazioni.getSelectedRow();
                    if(selectedRow != -1) {
                        int idCorsa = Integer.parseInt((String) tablePrenotazioni.getValueAt(selectedRow, 0));

                        try{
                            String compagnia = controller.recuperaCompagnia(idCorsa);

                            String telefono = controller.recuperaTelefonoCompagnia(compagnia);
                            String email = controller.recuperaEmailCompagnia(compagnia);
                            String sitoWeb = controller.recuperaSitoWebCompagnia(compagnia);
                            ArrayList<String> indirizzoSocial = controller.recuperaIndirizzoSocial(compagnia);

                            contattiCompagniaLabel.setText("Contatti della compagnia: ");
                            telefonoLabel.setText("Telefono: " + telefono);
                            mailLabel.setText("Email: " + email);
                            sitoWebLabel.setText("Sito Web: " + sitoWeb);
                            StringBuilder indirizziSocialText = new StringBuilder("Indirizzi Social: ");
                            for (String indirizzo : indirizzoSocial) {
                                indirizziSocialText.append(indirizzo).append(", ");
                            }
                            // Rimuovi l'ultima virgola aggiunta in eccesso
                            if (indirizziSocialText.length() > 0) {
                                indirizziSocialText.deleteCharAt(indirizziSocialText.length() - 2);
                            }
                            indirizziSocialLabel.setText(indirizziSocialText.toString());

                        } catch (SQLException ex) {
                            throw new RuntimeException(ex);
                        }

                    }
                }
            }
        });
    }

    /**
     * Aggiorna la tabella delle prenotazioni con i dati forniti.
     *
     * @param model Il modello della tabella
     * @param corsa Lista contenente i dati delle prenotazioni
     */
    private void aggiornaTabella(DefaultTableModel model, ArrayList<String[]> corsa) {
        model.setRowCount(0); // Rimuove tutte le righe attualmente presenti nel modello
        int indiceRitardo = 5;
        int indiceScalo = 4;
        for (int i = 0; i < corsa.size(); i++) {

            String[] rowData = corsa.get(i);
            String ritardo = rowData[indiceRitardo];
            if (ritardo == null || ritardo.isEmpty() || ritardo.equals("null")) {
                rowData[indiceRitardo] = "Nessun ritardo";
            }
            String scalo = rowData[indiceScalo];
            if (scalo == null || scalo.isEmpty() || scalo.equals("null")) {
                rowData[indiceScalo] = "Nessuno scalo";
            }
            model.addRow(rowData);
        }

    }

    /**
     * Calcola l'età in anni sulla base della data di nascita fornita.
     *
     * @param birthDate La data di nascita dell'utente
     * @return L'età in anni dell'utente
     */
    private int calculateAge(Date birthDate) {
        Calendar birthCalendar = Calendar.getInstance();
        birthCalendar.setTime(birthDate);
        Calendar now = Calendar.getInstance();

        int years = now.get(Calendar.YEAR) - birthCalendar.get(Calendar.YEAR);

        if (now.get(Calendar.DAY_OF_YEAR) < birthCalendar.get(Calendar.DAY_OF_YEAR)) {
            years--;
        }

        return years;
    }
}
