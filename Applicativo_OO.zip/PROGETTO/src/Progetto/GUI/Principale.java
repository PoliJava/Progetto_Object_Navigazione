package Progetto.GUI;

import Progetto.GUI.Controller.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Questa classe rappresenta la schermata principale dell'applicazione.
 */
public class Principale extends JFrame {

    /**
     * Il frame principale
     */
    public static JFrame frame = new JFrame("Principale");;
    private JButton compagniaDiNavigazioneButton;
    private JButton utenteButton;
    private JPanel Principale;
    /**
     * Il controller che gestisce la logica dell'applicazione.
     */
    public Controller controller=  new Controller();

    /**
     * Istanzia un nuovo oggetto Principale.
     */
    public Principale () {

        compagniaDiNavigazioneButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                PaginaCompagnia paginaCompagnia= new PaginaCompagnia(controller,frame);
                frame.setVisible(false);
                paginaCompagnia.frame2.setVisible(true);
            }
        });

        utenteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                HomeUtente homeUtente= new HomeUtente(controller,frame);
                frame.setVisible(false);
                homeUtente.frame4.setVisible(true);
            }
        });
    }

    /**
     * Il metodo main dell'applicazione.
     *
     * @param args gli argomenti passati da riga di comando
     */
    public static void main(String[] args) {
        frame.setContentPane(new Principale().Principale);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
        frame.setSize(800, 500);
    }
}
