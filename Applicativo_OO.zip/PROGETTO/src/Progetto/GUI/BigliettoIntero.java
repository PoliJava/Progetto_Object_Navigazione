package Progetto.GUI;

/**
 * Classe che rappresenta un biglietto intero.
 */
public class BigliettoIntero {
    /**
     * Prezzo totale del biglietto, che comprende evenutali sovrapprezzi.
     */
    public float prezzo;
    /**
     * Nominativo associato al biglietto.
     */
    public String nominativo;
    /**
     * Passeggero a cui è associato il biglietto.
     */
    Passeggero passeggero;
    /**
     * Prenotazione relativa al biglietto.
     */
    Prenotazione prenotazione;


    /**
     * Costruttore per la classe BigliettoIntero.
     *
     * @param nominativo nominativo associato al biglietto
     * @param prezzo     prezzo del biglietto
     * @param p          passeggero a cui è associato il biglieetto
     * @param pre        prenotazione relativa al biglietto
     */
    public BigliettoIntero(String nominativo, float prezzo, Passeggero p, Prenotazione pre)
    {
        this.nominativo = nominativo;
        this.prezzo=prezzo;
        passeggero = p;
        prenotazione = pre;
    }

}