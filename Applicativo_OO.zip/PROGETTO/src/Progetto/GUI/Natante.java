package Progetto.GUI;

import java.util.ArrayList;

/**
 * Rappresenta un natante utilizzato per il trasporto di passeggeri e automezzi.
 */
public class Natante {
    /**
     * La capienza massima di passeggeri del natante.
     */
    public int capienzaPassegeri;
    /**
     * La capienza massima di automezzi del natante.
     */
    public int capienzaAutomezzi;
    /**
     * Il tipo di natante.
     */
    public String tipoNatante;
    /**
     * La compagnia di trasporti che possiede il natante.
     */
    Compagnia compagnia;
    /**
     * Le tratte gestite dal natante.
     */
    ArrayList<Tratta> tratta;

    /**
     * Costruisce una nuova istanza di Natante con la capienza passeggeri, la capienza automezzi,
     * il tipo di natante, la compagnia e la tratta specificate.
     *
     * @param capienzaPassegeri la capienza massima di passeggeri del natante
     * @param capienzaAutomezzi la capienza massima di automezzi del natante
     * @param tipoNatante        il tipo di natante
     * @param comp               la compagnia di trasporti che possiede il natante
     * @param t                  la tratta gestita dal natante
     */
    public Natante(int capienzaPassegeri, int capienzaAutomezzi, String tipoNatante, Compagnia comp, Tratta t) {
        this.capienzaPassegeri = capienzaPassegeri;
        this.capienzaAutomezzi = capienzaAutomezzi;
        this.tipoNatante = tipoNatante;
        compagnia = comp;
        tratta.add(t);
    }
}
