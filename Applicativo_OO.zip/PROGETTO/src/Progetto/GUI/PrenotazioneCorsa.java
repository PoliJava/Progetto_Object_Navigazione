package Progetto.GUI;

import javax.swing.*;
import Progetto.GUI.Controller.Controller;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

/**
 * Questa classe rappresenta l'interfaccia grafica per effettuare una prenotazione per un viaggio.
 */
public class PrenotazioneCorsa extends JFrame{
    private JPanel prenotazione;
    private JTextField pesoBagagli;
    private JButton prenotaButton;
    private JPanel prenota;
    private JButton indietroButton;
    private JLabel MessaggioPrenotazioneEffettuata;
    private JPanel MessaggioErroreSQL;
    private JSpinner numeroBiglietti;
    private JComboBox <Boolean> sceltaAutoCombo;
    /**
     * Controller.
     */
    public Controller controller;
    /**
     * Il Frame chiamante.
     */
    public JFrame frameChiamante;
    /**
     * Il Frame prenotazione.
     */
    public JFrame framePrenotazione = new JFrame("Prenotazione Corsa");

    /**
     * Istanzia una nuova PrenotazioneCorsa.
     *
     * @param controller     il controller
     * @param frameChiamante il frame chiamante
     * @param idPasseggero   l'id passeggero
     * @param idCorsa        l'id corsa
     */
    public PrenotazioneCorsa (Controller controller, JFrame frameChiamante, int idPasseggero, int idCorsa) {
        this.controller = controller;
        framePrenotazione = new JFrame("Pagina Utente");
        framePrenotazione.setContentPane(prenotazione);
        framePrenotazione.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        framePrenotazione.pack();
        framePrenotazione.setVisible(true);
        framePrenotazione.setSize(800, 500);

        SpinnerModel spinnerModel = new SpinnerNumberModel(1, 1, 5, 1); // Valore iniziale, valore minimo, valore massimo, passo
        numeroBiglietti.setModel(spinnerModel); // Imposta il modello dello spinner


        Boolean[] options = {false, true};
        for (Boolean option : options) {
            sceltaAutoCombo.addItem(option);
        }

        sceltaAutoCombo.setRenderer(new DefaultListCellRenderer() {
            public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                // Chiamata al metodo della classe padre per la resa di base
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                // Se il valore è un booleano, impostiamo il testo sulla JComboBox come "No" o "Si"
                if (value instanceof Boolean) {
                    Boolean boolValue = (Boolean) value;
                    if (boolValue) {
                        setText("Sì");
                    } else {
                        setText("No");
                    }
                }
                return this;
            }
        });

        prenotaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                float pesoBagaglio = Float.parseFloat(pesoBagagli.getText());
                int numPrenotazioni = (int) numeroBiglietti.getValue();
                boolean sceltaAuto = (boolean) sceltaAutoCombo.getSelectedItem();

                try {
                    for (int i = 0; i < numPrenotazioni; i++) {
                        controller.creaPrenotazione(idPasseggero, pesoBagaglio, sceltaAuto, idCorsa);
                    }
                    MessaggioPrenotazioneEffettuata.setText("Prenotazione effettuata");
                } catch (SQLException ex) {
                    String errorMessage = "Errore di PostgreSQL: " + ex.getMessage();
                    MessaggioPrenotazioneEffettuata.setText(errorMessage);
                }
            }
        });

        indietroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                framePrenotazione.setVisible(false);
                frameChiamante.setVisible(true);
            }
        });
    }
}
