package Progetto.GUI;

/**
 * Rappresenta un indirizzo social associato a una compagnia di trasporti.
 */
public class IndirizzoSocial {
    /**
     * Lo username dell'indirizzo social.
     */
    public String username;

    /**
     * La compagnia di trasporti associata all'indirizzo social.
     */
    Compagnia compagnia;

    /**
     * Costruisce una nuova istanza di IndirizzoSocial con lo username e la compagnia specificati.
     *
     * @param username lo username dell'indirizzo social
     * @param c        la compagnia di trasporti associata all'indirizzo social
     */
    public IndirizzoSocial(String username, Compagnia c) {
        this.username = username;
        compagnia = c;
    }
}
