package Progetto.GUI;

import Progetto.GUI.Controller.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

/**
 * Questa classe rappresenta la pagina della compagnia, dove gli utenti possono controllare le informazioni relative alla compagnia.
 */
public class PaginaCompagnia extends JFrame {


    private JPanel JPanel2;
    private JButton TornaPrincipale;
    /**
     * Campo di testo per inserire il nome della compagnia da controllare.
     */
    public JTextField ControlloCompagnia;
    private JButton inviaButton;
    private JLabel MessaggioAccesso;
    /**
     * Il frame per la pagina della compagnia.
     */
    public JFrame frame2;
    /**
     * Il frame chiamante.
     */
    public JFrame frameChiamante;
    /**
     * Il controller per gestire le azioni dell'utente.
     */
    public Controller controller;


    /**
     * Costruisce una nuova istanza di PaginaCompagnia.
     *
     * @param controller     il controller per gestire le azioni dell'utente
     * @param frameChiamante il frame chiamante
     */
    public PaginaCompagnia(Controller controller, JFrame frameChiamante) {
        this.controller = controller;
        frame2 = new JFrame("Pagina Compagnia");
        frame2.setContentPane(JPanel2);
        frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame2.pack();
        frame2.setVisible(true);
        frame2.setSize(800, 500);


        TornaPrincipale.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                frame2.setVisible(false);
                frameChiamante.setVisible(true);

            }

        });

        inviaButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                String CompagniaInserita = ControlloCompagnia.getText();
                try {
                    if (CompagniaInserita.compareTo(controller.verificaNome(CompagniaInserita)) == 0) {

                        TabellaTratte tabellaCorse = new TabellaTratte(controller, frameChiamante, CompagniaInserita);
                        frame2.setVisible(false);
                        tabellaCorse.tabella.setVisible(true);

                    } else {
                        MessaggioAccesso.setText("I dati inseriti non sono corretti. Riprovare");
                    }
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
    }
}
