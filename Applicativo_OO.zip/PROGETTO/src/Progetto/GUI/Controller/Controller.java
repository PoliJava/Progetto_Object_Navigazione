package Progetto.GUI.Controller;

import Progetto.GUI.DAO.Implementazioni;
import Progetto.GUI.EsecuzioniQuery.ImplementazionePostgre;
import Progetto.GUI.*;

import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;

/**
 * Classe che funge da controller per gestire le interazioni tra la GUI e il database.
 */
public class Controller {
    private BigliettoIntero bigliettoIntero;
    private BigliettoRidotto bigliettoRidotto;
    private Compagnia compagnia;
    private Corsa corsa;
    private Giorno giorno;
    private IndirizzoSocial indirizzoSocial;
    private Natante natante;
    private Passeggero passeggero;
    private Prenotazione prenotazione;
    private Tratta tratta;

    /**
     * Verifica se il nome della compagnia è presente nel database
     *
     * @param compagniaInserita il nome della compagnia che viene inserito dall'utente
     * @return il nome della compagnia se è stato trovato nel database, altrimenti è null
     * @throws SQLException se si verifica un errore durante l'esecuzione della query
     */
    public String verificaNome(String compagniaInserita) throws SQLException {
        String verificaNome;
        Implementazioni implementazioni = new ImplementazionePostgre();
        try
        {
            verificaNome = implementazioni.verificaNome(compagniaInserita);
        }catch(SQLException e)
        {
            throw new RuntimeException(e);
        }
        return verificaNome;

    }

    /**
     * Tabella partenza trova tutte le città di partenza delle tratte offerte dalla compagnia di navigazione inserita
     *
     * @param CompagniaInserita il nome della compagnia che viene inserito dall'utente
     * @return restituisce l'arrayList delle citta di partenza per la compagnia
     * @throws SQLException se si verifica un errore durante l'esecuzione della query
     */
    public ArrayList<String> tabellaPartenza(String CompagniaInserita) throws SQLException
     {
         ArrayList<String> cercapartenze = new ArrayList<>();
         Implementazioni implementazioni= new ImplementazionePostgre();

         try{
             implementazioni.cercaPartenze(CompagniaInserita,cercapartenze);
         }catch(SQLException e){
             throw new RuntimeException(e);
         }
         return cercapartenze;

     }

    /**
     * Tabella arrivi trova tutte le città di arrivo delle tratte offerte dalla compagnia di navigazione inserita.
     *
     * @param CompagniaInserita il nome della compagnia che viene inserito dall'utente.
     * @return restituisce l'arrayList delle citta di arrivo per la compagnia.
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public ArrayList<String> tabellaArrivi(String CompagniaInserita) throws SQLException
    {
        ArrayList<String> cercaArrivi = new ArrayList<>();
        Implementazioni implementazioni= new ImplementazionePostgre();

        try{
            implementazioni.cercaArrivo(CompagniaInserita,cercaArrivi);
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
        return cercaArrivi;

    }

    /**
     * Tabella scalo trova tutti gli scali delle tratte offerte dalla compagnia di navigazione inserita.
     *
     * @param compagniaInserita il nome della compagnia che viene inserito dall'utente.
     * @return restituisce l'arrayList degli scali per la compagnia.
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public ArrayList<String> tabellaScalo(String compagniaInserita) throws SQLException
    {
        ArrayList<String> cercaScali = new ArrayList<>();
        Implementazioni implementazioni = new ImplementazionePostgre();

        try{
            implementazioni.cercaScalo(compagniaInserita,cercaScali);
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
        return cercaScali;

    }

    /**
     * Tabella id trova tutti gli id delle tratte offerte dalla compagnia di navigazione inserita.
     *
     * @param CompagniaInserita il nome della compagnia che viene inserito dall'utente.
     * @return restituisce l'arrayList degli id tratta per la compagnia.
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public ArrayList<Integer> tabellaID(String CompagniaInserita) throws SQLException
    {
        ArrayList<Integer> cercaId = new ArrayList<>();
        Implementazioni implementazioni= new ImplementazionePostgre();

        try{
            implementazioni.cercaID(CompagniaInserita,cercaId);
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
        return cercaId;

    }

    /**
     * Modificare ritardo: attraverso la query, permette di modificare il ritardo della corsa, in base all'idCorsa inserito
     *
     * @param id              indica l'id della corsa di cui bisogna modificare il ritardo
     * @param ritardoInserito indica il valore del ritardo da andare a sostituire nel database
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public void modificareRitardo(int id, String ritardoInserito) throws SQLException{

        Implementazioni implementazioni= new ImplementazionePostgre();
        try
        {
            implementazioni.modificareRitardo(id,ritardoInserito);
            System.out.println("Dati inseriti correttamente nel database.");

        }catch(SQLException e)
        {

            throw new RuntimeException(e);
        }
    }

    /**
     * Verifica utente boolean: verifica se nel database esiste un passeggero con i dati specificati dall'utente.
     *
     * @param nome        indica il nome da trovare nel database.
     * @param cognome     indica il cognome da trovare nel database.
     * @param dataNascita indica la data di nascita da trovare nel database.
     * @return restituisce un booleano per indicare se la tupla è stata trovata oppure no.
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public boolean verificaUtente(String nome, String cognome, Date dataNascita) throws SQLException {

        Boolean verificaUtente;
        Implementazioni implementazioni= new ImplementazionePostgre();
        try
        {
            verificaUtente = implementazioni.verificaUtente(nome, cognome, dataNascita);
            return verificaUtente;

        }catch(SQLException e)
        {
            throw new RuntimeException(e);
        }

    }

    /**
     * Crea utente: in base ai dati inseriti dall'utente inserisce una nuova tupla nella tabella passeggero.
     *
     * @param nome        indica il nome da trovare nel database.
     * @param cognome     indica il cognome da trovare nel database.
     * @param dataNascita indica la data di nascita da trovare nel database.
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public void creaUtente(String nome, String cognome, Date dataNascita) throws SQLException {

        Implementazioni implementazioni= new ImplementazionePostgre();
        try
        {
            implementazioni.creaUtente(nome, cognome, dataNascita);
            System.out.println("Dati inseriti correttamente nel database.");

        }catch(SQLException e)
        {

            throw new RuntimeException(e);
        }
    }

    /**
     * trova tutte le corse e altre informazioni legate a queste attraverso la query
     *
     * @param cittaPartenza citta di Partenza della corsa
     * @param cittaArrivo   citta di Arrivo della corsa
     * @param natante       natante associato alla corsa
     * @param giorno        data in cui si tiene la corsa
     * @param orario        orario di partenza della corsa
     * @param prezzo        prezzo della tratta
     * @return restituisce l'arrayList di tutte le corse trovate e queste saranno visualizzate in una tabella
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public ArrayList<String[]> cercaCorse (String cittaPartenza, String cittaArrivo, String natante, Date giorno, Time orario, double prezzo) throws SQLException {

        ArrayList<String[]> resultData = new ArrayList<>();
        Implementazioni implementazioni = new ImplementazionePostgre();

        try {
            implementazioni.stampaTabellaCorse(cittaPartenza, cittaArrivo, natante, giorno, orario, prezzo, resultData);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return resultData;
    }

    /**
     * Stampa le corse filtrate in base a valori inseriti dall'utente.
     *
     * @return arrayList tutte le corse filtrate.
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public ArrayList<String[]> stampaCorseTabella () throws SQLException {
        ArrayList<String[]> resultData = new ArrayList<>();
        Implementazioni implementazioni = new ImplementazionePostgre();

        try {
            implementazioni.stampaTabellaCompleta(resultData);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return resultData;
    }

    /**
     * Cerca l'id del passeggero in base ai dati inseriti dall'utente per il login o la registrazione
     *
     * @param nome        nome inserito dall'utente
     * @param cognome     cognome inserito dall'utente
     * @param dataNascita data di nascita inserita dall'utente
     * @return l'id del passeggero trovato, altrimenti null.
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public int cercaIdPasseggero(String nome, String cognome, Date dataNascita) throws SQLException {

        Implementazioni implementazioni = new ImplementazionePostgre();
        int idPasseggero;
        try {
            idPasseggero = implementazioni.cercaIdPasseggero(nome, cognome, dataNascita);
        } catch(SQLException e) {
            throw new RuntimeException(e);
        }

        return idPasseggero;
    }

    /**
     * Crea una prenotazione per il passeggero che ha effettuato l'accesso e in base alla corsa che si vuole prenotare.
     * Per completare la prenotazione vengono inseriti da tastiera il pesoBagagli e l'eventuale presenza di un'auto.
     *
     * @param idPasseggero id del passeggero che prenota la corsa
     * @param pesoBagagli  peso del bagaglio per calcolare il sovrapprezzo
     * @param auto         auto per indicare se presente o meno
     * @param idCorsa      id della corsa che si sta prenotando
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public void creaPrenotazione(int idPasseggero, float pesoBagagli, boolean auto, int idCorsa) throws SQLException {

        Implementazioni implementazioni = new ImplementazionePostgre();
        try
        {
            implementazioni.creaPrenotazione(idPasseggero, pesoBagagli, auto, idCorsa);
            System.out.println("Dati inseriti correttamente nel database.");

        }catch(SQLException e)
        {
            throw new RuntimeException(e);
        }
    }

    /**
     * Stampa la tabella delle prenotazioni effettuate dall'utente (maggiorenne) che ha effettuato l'accesso e che quindi sta utilizzando il programma.
     *
     * @param idpasseggero id del passeggero passato per filtrare le prenotazioni nel database.
     * @return arrayList delle prenotazioni
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public ArrayList<String[]> stampaTabellaPrenotazioniIntero (Integer idpasseggero) throws SQLException {

        ArrayList<String[]> resultData = new ArrayList<>();
        Implementazioni implementazioni = new ImplementazionePostgre();

        try {
            implementazioni.stampaTabellaPrenotazioniIntero(idpasseggero, resultData);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return resultData;
    }

    /**
     * Stampa la tabella delle prenotazioni effettuate dall'utente (minorenne) che ha effettuato l'accesso e che quindi sta utilizzando il programma.
     *
     * @param idpasseggero id del passeggero passato per filtrare le prenotazioni nel database.
     * @return arrayList delle prenotazioni
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public ArrayList<String[]> stampaTabellaPrenotazioniRidotto (Integer idpasseggero) throws SQLException {

        ArrayList<String[]> resultData = new ArrayList<>();
        Implementazioni implementazioni = new ImplementazionePostgre();

        try {
            implementazioni.stampaTabellaPrenotazioniRidotto(idpasseggero, resultData);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return resultData;
    }

    /**
     * Cerca la data di nascita dell'utente che ha effettuato l'accesso. Serve per calcolarne l'età e quindi per poter stampare la tabella con le prenotazioni per quello specifico utente
     *
     * @param idpasseggero id del passeggero di cui si vuole trovare la data di nascita
     * @return la data di nascita del passeggero
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public Date cercaDataNascita (Integer idpasseggero) throws SQLException {
        Implementazioni implementazioni = new ImplementazionePostgre();
        Date dataNascita;
        try {
            dataNascita = implementazioni.recuperaDataNascita(idpasseggero);
        } catch(SQLException e) {
            throw new RuntimeException(e);
        }

        return dataNascita;
    }

    /**
     * Elimina la prenotazione da database, per il passeggero che ha acquistato un biglietto intero.
     *
     * @param idprenotazione id della prenotazione da eliminare.
     * @param idpasseggero   id del passeggero per cui si elimina la prenotazione.
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public void eliminaPrenotazioneIntero(int idprenotazione, int idpasseggero) throws SQLException {

        Implementazioni implementazioni = new ImplementazionePostgre();
        try {
            implementazioni.eliminaPrenotazioneIntero(idprenotazione, idpasseggero);
        } catch (SQLException e){
            throw new RuntimeException(e);
        }
    }

    /**
     * Elimina la prenotazione dal database, per il passeggero che ha acquistato un biglietto ridotto.
     *
     * @param idprenotazione id della prenotazione da eliminare
     * @param idpasseggero   id del passeggero per cui si elimina la prenotazione
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public void eliminaPrenotazioneRidotto(int idprenotazione, int idpasseggero) throws SQLException {

        Implementazioni implementazioni = new ImplementazionePostgre();
        try {
            implementazioni.eliminaPrenotazioneRidotto(idprenotazione, idpasseggero);
        } catch (SQLException e){
            throw new RuntimeException(e);
        }
    }

    /**
     * Cerca il numero di telefono della compagnia di cui si sta selezionando la corsa.
     *
     * @param compagnia viene passato il nome della compagnia per filtrare i dati nel database
     * @return il numero di telefono trovato
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public String recuperaTelefonoCompagnia(String compagnia) throws SQLException {
        String telefono;
        Implementazioni implementazioni = new ImplementazionePostgre();
        try{
            telefono = implementazioni.recuperaTelefonoCompagnia(compagnia);
        }catch(SQLException e) {
            throw new RuntimeException(e);
        }
        return telefono;
    }

    /**
     * Cerca la mail della compagnia di cui si sta selezionando la corsa.
     *
     * @param compagnia viene passato il nome della compagnia per filtrare i dati nel database
     * @return la mail trovata
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public String recuperaEmailCompagnia(String compagnia) throws SQLException {
        String email;
        Implementazioni implementazioni = new ImplementazionePostgre();
        try{
            email = implementazioni.recuperaEmailCompagnia(compagnia);
        }catch(SQLException e) {
            throw new RuntimeException(e);
        }
        return email;
    }

    /**
     * Cerca il sito web della compagnia di cui si sta selezionando la corsa.
     *
     * @param compagnia viene passato il nome della compagnia per filtrare i dati nel database
     * @return il sito web trovato
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public String recuperaSitoWebCompagnia(String compagnia) throws SQLException {
        String sitoWeb;
        Implementazioni implementazioni = new ImplementazionePostgre();
        try{
            sitoWeb = implementazioni.recuperaSitoWeb(compagnia);
        }catch(SQLException e) {
            throw new RuntimeException(e);
        }
        return sitoWeb;
    }

    /**
     * Cerca gli indirizzi social della compagnia di cui si sta selezionando la corsa.
     *
     * @param compagnia viene passato il nome della compagnia per filtrare i dati nel database
     * @return gli indirizzi social trovati
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public ArrayList<String> recuperaIndirizzoSocial(String compagnia) throws SQLException {
        ArrayList<String> indirizzoSocial;
        Implementazioni implementazioni = new ImplementazionePostgre();
        try{
            indirizzoSocial = implementazioni.recuperaIndirizziSocial(compagnia);
        }catch(SQLException e) {
            throw new RuntimeException(e);
        }
        return indirizzoSocial;
    }

    /**
     * Cerca la compagnia di navigazione attraverso l'id della corsa selezionata.
     *
     * @param idcorsa id della corsa selezionata
     * @return il nome della compagnia che sarà passato come parametro per trovare numero di telefono, mail etc...
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public String recuperaCompagnia (Integer idcorsa) throws SQLException{
        String compagnia;
        Implementazioni implementazioni = new ImplementazionePostgre();
        try{
            compagnia = implementazioni.recuperaCompagnia(idcorsa);
        } catch (SQLException e){
            throw new RuntimeException(e);
        }
        return compagnia;
    }

    /**
     * Cerca tutte le corse per una tratta specificata dalla compagnia, servirà poi per modificare il ritardo.
     *
     * @param idInserito        id della tratta per filtrare i risultati
     * @param CompagniaInserita id della compagnia per cui si andrano a visualizzare tratte e corse
     * @return arrayList di tutte le corse per quella tratta
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public ArrayList<String[]>  stampaTabellaCorseTratte (int idInserito, String CompagniaInserita) throws SQLException {
        ArrayList<String[]> resultData = new ArrayList<>();
        Implementazioni implementazioni = new ImplementazionePostgre();

        try {
            implementazioni.stampaTabellaCorseTratte(idInserito,CompagniaInserita,resultData);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return resultData;
    }

    /**
     * Cerca gli id della corsa attraverso id tratta e nomecompagnia.
     *
     * @param idInserito        id della tratta inserito per filtrare i risultati
     * @param CompagniaInserita nome della compagnia di navigazione per filtrare i risultati
     * @return arrayList degli id della corsa trovati in base alla query
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public ArrayList<String[]>  recuperoIDcorsa (int idInserito, String CompagniaInserita) throws SQLException {
        ArrayList<String[]> resultData = new ArrayList<>();
        Implementazioni implementazioni = new ImplementazionePostgre();

        try {
            implementazioni.recuperoIDcorsa(idInserito,CompagniaInserita,resultData);

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return resultData;
    }

    /**
     * Permette di modificare lo scalo di una tratta specificata.
     *
     * @param idInserito    id della tratta da modificare
     * @param scaloInserito valore dello scalo da inserire al posto di quello precedente
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public void modificaScalo(int idInserito, String scaloInserito) throws SQLException {

        Implementazioni implementazioni= new ImplementazionePostgre();
        try
        {
            implementazioni.modificaScalo(idInserito,scaloInserito);
            System.out.println("Dati inseriti correttamente nel database.");

        }catch(SQLException e)
        {

            throw new RuntimeException(e);
        }


    }

    /**
     * Inserisce una tupla nella relazione cadenzaGiornaliera del database, per creare una cadenza giornaliera da associare a una tratta.
     *
     * @param datainizio             data di inizio del periodo in cui è attiva la tratta
     * @param datafine               data di fine del periodo in cui è attiva la tratta
     * @param giornosettimanale      giorni settimanali in cui è attiva la tratta
     * @param orariopartenza         orario di partenza della tratta
     * @param orarioarrivo           orario di arrivo della tratta
     * @param nomecadenzagiornaliera nome cadenza giornaliera è la chiave primaria nella relazione del database,
     *                               ci servirà anche successivamente per associare la tratta da inserire alla specifica cadenzagiornaliera
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public void creaCadenzaGiornaliera(Date datainizio,Date datafine, String giornosettimanale,Time orariopartenza,Time orarioarrivo,String nomecadenzagiornaliera ) throws SQLException {

        Implementazioni implementazioni= new ImplementazionePostgre();
        try
        {
            implementazioni.creaCadenzaGiornaliera(datainizio,datafine,giornosettimanale,orariopartenza,orarioarrivo,nomecadenzagiornaliera);
            System.out.println("Dati inseriti correttamente nel database.");

        }catch(SQLException e)
        {

            throw new RuntimeException(e);
        }
    }

    /**
     * Inserisce una tupla in tratta, in base ai valori inseriti dall'utente. Con la creazione della tratta (per mano del database) saranno create anche le rispettive corse.
     *
     * @param cittaPartenza          citta di partenza della tratta
     * @param cittaArrivo            citta di arrivo della tratta
     * @param scalo                  eventuale scalo
     * @param compagniaInserita      compagnia di cui si sta inserendo la tratta
     * @param nomeCadenzaGiornaliera nome della cadenza giornaliera da associare alla tratta
     * @param prezzo                 prezzo base della tratta
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public void creatratta(String cittaPartenza,String cittaArrivo,String scalo, String compagniaInserita,String nomeCadenzaGiornaliera,float prezzo ) throws SQLException {

        Implementazioni implementazioni= new ImplementazionePostgre();
        try
        {
            implementazioni.creatratta(cittaPartenza,cittaArrivo,scalo,compagniaInserita,nomeCadenzaGiornaliera,prezzo);
            System.out.println("Dati inseriti correttamente nel database.");

        }catch(SQLException e)
        {

            throw new RuntimeException(e);
        }
    }

    /**
     * Stampa la tabella dei natanti per la compagnia che ha effettuato l'accesso e che sta utilizzando il programma.
     *
     * @param compagnia compagnia di navigazione per filtrare i risultati
     * @return arrayList dei natanti trovati
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public ArrayList<String[]> stampaTabellaNatanti(String compagnia) throws SQLException{

        ArrayList<String[]> result = new ArrayList<>();
        Implementazioni implementazioni = new ImplementazionePostgre();
        try {
            implementazioni.stampaTabellaNatanti(compagnia, result);
        } catch(SQLException e) {
            throw new RuntimeException(e);
        }
        return result;
    }

    /**
     * Permette di inserire un nuovo natante per la compagnia che ha effettuato l'accesso.
     *
     * @param codnatante    codice del natante
     * @param tipoNatante   tipo del natante (traghetto, aliscafo, motonave, altro)
     * @param nomeCompagnia nome della compagnia per cui si inserisce il natante
     * @param capienzaP     capienza passeggeri del natante
     * @param capienzaA     capienza automezzi del natante (maggiore di 0 solo per i traghetti)
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public void inserimentoNatante(String codnatante, String tipoNatante, String nomeCompagnia, Integer capienzaP, Integer capienzaA) throws SQLException {

        Implementazioni implementazioni= new ImplementazionePostgre();
        try
        {
            implementazioni.inserimentoNatante(codnatante, tipoNatante, nomeCompagnia, capienzaP, capienzaA);
            System.out.println("Dati inseriti correttamente nel database.");

        }catch(SQLException e)
        {

            throw new RuntimeException(e);
        }
    }

    /**
     * Cerca tutti i natanti associati alle tratte della compagnia di navigazione che sta utilizzando il programma.
     *
     * @param CompagniaInserita compagnia di navigazione per filtrare i natanti
     * @return arrayList dei codici dei natanti
     * @throws SQLException se si verifica un errore durante l'esecuzione della query.
     */
    public ArrayList<String> tabellaCodNatante(String CompagniaInserita) throws SQLException
    {
        ArrayList<String> cercaNatanti = new ArrayList<>();
        Implementazioni implementazioni= new ImplementazionePostgre();

        try{
            implementazioni.cercaNatante(CompagniaInserita,cercaNatanti);
        }catch(SQLException e){
            throw new RuntimeException(e);
        }
        return cercaNatanti;

    }

}


