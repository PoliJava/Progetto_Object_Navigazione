package Progetto.GUI;

import Progetto.GUI.Controller.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Questa classe rappresenta la schermata iniziale per l'utente, che consente di accedere o registrarsi.
 */
public class HomeUtente extends JFrame {
    /**
     * Il frame per la schermata "Accedi o registrati".
     */
    public static JFrame frame4 = new JFrame("Accedi o registrati");
    private JPanel Home;
    private JButton registratiButton;
    private JButton accediButton;
    private JButton indietroButton;
    private JPanel Testo;

    /**
     * Il controller per gestire le azioni dell'utente.
     */
    public Controller controller;

    /**
     * Costruisce una nuova istanza di HomeUtente.
     *
     * @param controller     il controller per gestire le azioni dell'utente
     * @param frameChiamante il frame chiamante
     */
    public HomeUtente(Controller controller, JFrame frameChiamante) {

        this.controller = controller;
        frame4 = new JFrame("Home Utente");
        frame4.setContentPane(Home);
        frame4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame4.pack();
        frame4.setVisible(true);
        frame4.setSize(800, 500);


        accediButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                LoginUtente loginUtente = new LoginUtente(controller, frame4);
                frame4.setVisible(false);
                loginUtente.frame5.setVisible(true);
            }
        });


        registratiButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                RegistrazioneUtente registrazioneUtente = new RegistrazioneUtente(controller, frame4);
                frame4.setVisible(false);
                registrazioneUtente.frame6.setVisible(true);
            }
        });

        indietroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame4.setVisible(false);
                frameChiamante.setVisible(true);
            }
        });
    }
}
