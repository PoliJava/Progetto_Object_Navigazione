package Progetto.GUI;

import Progetto.GUI.Controller.Controller;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * Rappresenta la pagina per l'inserimento di una nuova tratta.
 */
public class PaginaNuovaTratta {

    /**
     * Il frame per la pagina di inserimento di una nuova tratta.
     */
    public JFrame frameNuovaTratta;
    /**
     * Il controller per gestire le operazioni di inserimento della tratta.
     */
    public Controller controller;
    private JPanel PanelNuovaTratta;
    private JButton buttonIndietro;
    private JTextField testoCittaPartenza;
    private JTextField testoCittaArrivo;
    private JTextField testoScalo;
    private JTextField testoPrezzo;
    private JTextField testoGiorniSettimanali;
    private JTextField testoCadenzaGiornaliera;
    private JComboBox comboAnnoInizio;
    private JComboBox comboMeseInizio;
    private JComboBox comboGiornoInizio;
    private JComboBox comboAnnoFine;
    private JComboBox comboMeseFine;
    private JComboBox comboGiornoFine;
    private JComboBox comboOraPartenza;
    private JComboBox comboMinPartenza;
    private JComboBox comboOraArrivo;
    private JComboBox comboMinArrivo;
    private JButton buttonInserimentotratta;


    /**
     * Costruisce una nuova istanza di PaginaNuovaTratta.
     *
     * @param controller        il controller per gestire le operazioni di inserimento della tratta
     * @param tabella           il frame della tabella delle tratte
     * @param table1            il componente tabella
     * @param model             il modello della tabella
     * @param CompagniaInserita il nome della compagnia selezionata
     */
    public PaginaNuovaTratta(Controller controller, JFrame tabella, JTable table1, DefaultTableModel model, String CompagniaInserita) {
        this.controller = controller;
        frameNuovaTratta = new JFrame("Pagina Nuova Tratta");
        frameNuovaTratta.setContentPane(PanelNuovaTratta);
        frameNuovaTratta.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frameNuovaTratta.pack();
        frameNuovaTratta.setVisible(true);
        frameNuovaTratta.setSize(800, 500);

        Calendar cal = Calendar.getInstance();
        int currentYear = cal.get(Calendar.YEAR);
        for (int year = currentYear; year >= currentYear - 100; year--) {
            comboAnnoInizio.addItem(year);
        }
        for (int year = currentYear; year >= currentYear - 100; year--) {
            comboAnnoFine.addItem(year);
        }

        for (int month = 1; month <= 12; month++) {
            comboMeseInizio.addItem(month);
        }
        for (int month = 1; month <= 12; month++) {
            comboMeseFine.addItem(month);
        }

        for (int day = 1; day <= 31; day++) {
            comboGiornoInizio.addItem(day);
        }
        for (int day = 1; day <= 31; day++) {
            comboGiornoFine.addItem(day);
        }

        for (int hour = 0; hour < 24; hour++) {
            comboOraArrivo.addItem(hour);
        }


        for (int min = 0; min < 60; min++) {
            comboMinArrivo.addItem(min);
        }
        for (int hour = 0; hour < 24; hour++) {
            comboOraPartenza.addItem(hour);
        }


        for (int min = 0; min < 60; min++) {
            comboMinPartenza.addItem(min);
        }


        buttonIndietro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameNuovaTratta.setVisible(false);
               try {
                   ArrayList<String> partenze = controller.tabellaPartenza(CompagniaInserita);
                   ArrayList<String> arrivi = controller.tabellaArrivi(CompagniaInserita);
                   ArrayList<String> scali = controller.tabellaScalo(CompagniaInserita);
                   ArrayList<Integer> idtratta = controller.tabellaID(CompagniaInserita);
                   aggiornaTabella(model, idtratta, partenze, arrivi, scali);
               }catch (SQLException ex) {
                   throw new RuntimeException(ex);
               }
                tabella.setVisible(true);


            }
        });
        buttonInserimentotratta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Date datainizio=getDataInizio();
                Date datafine=getDataFine();
                String giornisettimanali=testoGiorniSettimanali.getText().trim();
                Time orarioArrivo=getOrarioArrivo();
                Time orarioPartenza=getOrarioPartenza();
                String nomecadenzagiornaliera=testoCadenzaGiornaliera.getText().trim();
                String cittaPartenza=testoCittaPartenza.getText().trim();
                String cittaArrivo=testoCittaArrivo.getText().trim();
                String scalo=testoScalo.getText().trim();
                float prezzo= Float.parseFloat(testoPrezzo.getText().trim());

                // Verifica che tutti i campi siano stati compilati correttamente
                if (!giornisettimanali.isEmpty() && !cittaPartenza.isEmpty() && !cittaArrivo.isEmpty() && !scalo.isEmpty() && prezzo!=0 && prezzo >0 && !nomecadenzagiornaliera.isEmpty() && datainizio != null && datafine != null && orarioArrivo != null && orarioPartenza != null) {
                    try {
                        controller.creaCadenzaGiornaliera(datainizio, datafine, giornisettimanali, orarioPartenza, orarioArrivo, nomecadenzagiornaliera);
                        controller.creatratta(cittaPartenza,cittaArrivo,scalo,CompagniaInserita,nomecadenzagiornaliera,prezzo);

                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                } else {
                    System.out.println("Alcuni campi sono vuoti o non sono stati selezionati correttamente. Si prega di compilare tutti i campi.");
                }
            }
        });
    }

    /**
     * Ottiene la data di inizio dalla selezione nelle JComboBox.
     *
     * @return la data di inizio selezionata
     */
    private Date getDataInizio() {
        // Ottieni la data selezionata dalle JComboBox
        int year = (int) comboAnnoInizio.getSelectedItem();
        int month = (int) comboMeseInizio.getSelectedItem();
        int day = (int) comboGiornoInizio.getSelectedItem();

        // Crea un oggetto Calendar e imposta l'anno, il mese e il giorno
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month - 1); // I mesi in Java Calendar iniziano da 0
        cal.set(Calendar.DAY_OF_MONTH, day);

        // Restituisci la data come oggetto Date
        return cal.getTime();
    }

    /**
     * Ottiene la data di fine dalla selezione nelle JComboBox.
     *
     * @return la data di fine selezionata
     */
    private Date getDataFine() {
        // Ottieni la data selezionata dalle JComboBox
        int year = (int) comboAnnoFine.getSelectedItem();
        int month = (int) comboMeseFine.getSelectedItem();
        int day = (int) comboGiornoFine.getSelectedItem();

        // Crea un oggetto Calendar e imposta l'anno, il mese e il giorno
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month - 1); // I mesi in Java Calendar iniziano da 0
        cal.set(Calendar.DAY_OF_MONTH, day);

        // Restituisci la data come oggetto Date
        return cal.getTime();
    }

    /**
     * Ottiene l'orario di partenza dalla selezione nelle JComboBox.
     *
     * @return l'orario di partenza selezionato
     */
    private Time getOrarioPartenza() {
        int hour = (int) comboOraPartenza.getSelectedItem();
        int min = (int) comboMinPartenza.getSelectedItem();

        return new Time(hour, min, 0);
    }
    /**
     * Ottiene l'orario di arrivo dalla selezione nelle JComboBox.
     *
     * @return l'orario di arrivo selezionato
     */
    private Time getOrarioArrivo() {
        int hour = (int) comboOraArrivo.getSelectedItem();
        int min = (int) comboMinArrivo.getSelectedItem();

        return new Time(hour, min, 0);
    }
    /**
     * Aggiorna la tabella delle tratte con i nuovi dati.
     *
     * @param model   il modello della tabella
     * @param idtratta l'elenco degli ID delle tratte
     * @param partenze l'elenco delle città di partenza
     * @param arrivi   l'elenco delle città di arrivo
     * @param scali    l'elenco degli scali
     */
    private void aggiornaTabella(DefaultTableModel model, ArrayList<Integer> idtratta , ArrayList<String> partenze, ArrayList<String> arrivi, ArrayList<String> scali) {
        model.setRowCount(0); // Rimuove tutte le righe attualmente presenti nel modello

        for (int i = 0; i < idtratta.size(); i++) {
            Integer ID = idtratta.get(i);
            String partenza = partenze.get(i);
            String arrivo = arrivi.get(i);
            String scalo = scali.get(i);

            if (scalo == null || scalo.isEmpty() || scalo.equals("null")) {
                scalo = "Nessuno scalo";
            }

            model.addRow(new Object[]{ID, partenza, arrivo, scalo});
        }
    }
}
