package Progetto.GUI;

import Progetto.GUI.Controller.Controller;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * La classe TabellaTratte gestisce la visualizzazione e l'interazione con la tabella delle tratte.
 */
public class TabellaTratte {
    private JTable table1;
    private JPanel panelTabella;
    private JPanel PanelPrincipale;
    public JFrame tabella;
    private JTextField testoIDinserito;
    private JButton invioButton;
    private JLabel MessaggioAccesso;
    private JButton INVIASCALO;
    private JButton ButtonInserisciScalo;
    private JTextField campoScalo;
    private JPanel panelScalo;
    private JLabel MessaggioErroreSelezione;
    private JButton buttonTornaIndietro;
    private JButton buttonInserisciNuovaTratta;
    private JButton ButtonInserisciNuovoNatante;
    private JPanel Panelinserimento;
    private JTextField textCittaPartenza;
    private JTextField textCittaArrivo;
    private JTextField textScalo;
    private JTextField textIDcorsa;
    private JTextField textNomeCadenzaGiornaliera;
    private JButton AGGIUNGICORSAButton;
    private JLabel messaggioInserimento;
    public Controller controller;

    /**
     * Costruisce un nuovo oggetto TabellaTratte.
     *
     * @param controller        il controller per interagire con il database
     * @param frame2            il frame chiamante
     * @param CompagniaInserita il nome della compagnia selezionata
     * @throws SQLException eccezione SQL
     */
    public TabellaTratte(Controller controller, JFrame frame2, String CompagniaInserita) throws SQLException {
        this.controller = controller;
        tabella = new JFrame("TABELLA TRATTE");
        tabella.setContentPane(PanelPrincipale);
        tabella.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        tabella.pack();
        tabella.setVisible(true);
        tabella.setSize(800, 500);
        panelScalo.setVisible(false);

        DefaultTableModel model = new DefaultTableModel(new Object[][]{}, new String[]{"ID TRATTA", "PARTENZE", "ARRIVI", "SCALI", "NATANTE ASSOCIATO"}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table1.setModel(model);
        table1.setRowHeight(50);
        panelTabella.setLayout(new BorderLayout());
        panelTabella.add(new JScrollPane(table1), BorderLayout.CENTER);

        // Recupera i dati dalla tabella e popola il modello
        ArrayList<String> partenze = controller.tabellaPartenza(CompagniaInserita);
        ArrayList<String> arrivi = controller.tabellaArrivi(CompagniaInserita);
        ArrayList<String> scali = controller.tabellaScalo(CompagniaInserita);
        ArrayList<Integer> idTratta = controller.tabellaID(CompagniaInserita);
        ArrayList<String> codNatante = controller.tabellaCodNatante(CompagniaInserita);
        aggiornaTabella(model, idTratta, partenze, arrivi, scali, codNatante);

        invioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (testoIDinserito.getText().equals("")) {
                    MessaggioAccesso.setText("Il campo e' vuoto. Riprovare");
                }
                else {

                    int idInserito = Integer.parseInt(testoIDinserito.getText());
                    boolean trovato = false;

                    try {
                        ArrayList<String> partenze = controller.tabellaPartenza(CompagniaInserita);
                        ArrayList<String> arrivi = controller.tabellaArrivi(CompagniaInserita);
                        ArrayList<String> scali = controller.tabellaScalo(CompagniaInserita);
                        ArrayList<Integer> idtratta = controller.tabellaID(CompagniaInserita);
                        ArrayList<String> codNatante = controller.tabellaCodNatante(CompagniaInserita);

                        aggiornaTabella(model, idtratta, partenze, arrivi, scali, codNatante);

                        for (int i = 0; i < idtratta.size(); i++) {
                            int id = idtratta.get(i);

                            if (idInserito == id) {

                                PaginaCorse paginaCorse = new PaginaCorse(controller, tabella, idInserito, CompagniaInserita, MessaggioAccesso);
                                tabella.setVisible(false);
                                paginaCorse.frameCorsa.setVisible(true);
                                break;
                            }

                        }

                        if (!trovato) {

                            MessaggioAccesso.setText("L'id inserito non è corretto. Riprovare");

                        }
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                }
            }
        });

        INVIASCALO.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table1.getSelectedRow();
                if (selectedRow != -1) {
                    String scalo = table1.getValueAt(selectedRow, 0).toString();
                    MessaggioErroreSelezione.setText("");
                    panelScalo.setVisible(true);

                    // Rimuovi eventuali ActionListener precedenti
                    ActionListener[] actionListeners = ButtonInserisciScalo.getActionListeners();
                    for (ActionListener listener : actionListeners) {
                        ButtonInserisciScalo.removeActionListener(listener);
                    }

                    ButtonInserisciScalo.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            String testoScalo = campoScalo.getText().trim();
                            try {
                                controller.modificaScalo(Integer.parseInt(scalo), testoScalo);
                                ArrayList<String> partenze = controller.tabellaPartenza(CompagniaInserita);
                                ArrayList<String> arrivi = controller.tabellaArrivi(CompagniaInserita);
                                ArrayList<String> scali = controller.tabellaScalo(CompagniaInserita);
                                ArrayList<Integer> idtratta = controller.tabellaID(CompagniaInserita);
                                ArrayList<String> codNatante = controller.tabellaCodNatante(CompagniaInserita);

                                aggiornaTabella(model, idtratta, partenze, arrivi, scali, codNatante);

                            } catch (SQLException ex) {
                                throw new RuntimeException(ex);
                            }
                            panelScalo.setVisible(false);
                        }
                    });
                } else {
                    MessaggioErroreSelezione.setText("Nessuna riga selezionata.");
                }
            }
        });

        buttonTornaIndietro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                       tabella.setVisible(false);
                       frame2.setVisible(true);
            }
        });
        buttonInserisciNuovaTratta.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PaginaNuovaTratta paginaNuovaTratta  = new PaginaNuovaTratta (controller,tabella,table1,model,CompagniaInserita);
                tabella.setVisible(false);
                paginaNuovaTratta.frameNuovaTratta.setVisible(true);

            }
        });
        ButtonInserisciNuovoNatante.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PaginaNuovoNatante paginaNuovoNatante  = new PaginaNuovoNatante (controller,tabella,CompagniaInserita);
                tabella.setVisible(false);
                paginaNuovoNatante.frameNuovoNatante.setVisible(true);

            }
        });
    }

    /**
     * Aggiorna il modello della tabella con i nuovi dati delle tratte.
     *
     * @param model     il modello della tabella
     * @param idtratta  lista degli ID delle tratte
     * @param partenze  lista delle città di partenza
     * @param arrivi    lista delle città di arrivo
     * @param scali     lista degli eventuali scali
     * @param codNat    lista dei codici natanti associati
     */
    private void aggiornaTabella(DefaultTableModel model, ArrayList<Integer> idtratta , ArrayList<String> partenze, ArrayList<String> arrivi, ArrayList<String> scali, ArrayList<String> codNat) {
        model.setRowCount(0); // Rimuove tutte le righe attualmente presenti nel modello

        for (int i = 0; i < idtratta.size(); i++) {
            Integer ID = idtratta.get(i);
            String partenza = partenze.get(i);
            String arrivo = arrivi.get(i);
            String scalo = scali.get(i);
            String codNatante = codNat.get(i);

            if (scalo == null || scalo.isEmpty() || scalo.equals("null")) {
                scalo = "Nessuno scalo";
            }

            model.addRow(new Object[]{ID, partenza, arrivo, scalo, codNatante});
        }
    }

}


