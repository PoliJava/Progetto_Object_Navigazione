package Progetto.GUI;

import Progetto.GUI.Controller.Controller;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * PaginaUtenteIntero è una classe che gestisce l'interfaccia grafica per la visualizzazione delle corse e l'effettuazione delle prenotazioni da parte degli utenti.
 */
public class PaginaUtenteIntero extends JFrame {
    private JPanel paginaUtenteIntero;
    private JTextField controlloPartenza;
    private JTextField controlloArrivo;
    private JButton INVIOButton;
    private JButton TornaPrincipale;
    private JLabel messaggioAccesso;
    private JPanel titolo;
    private JTextField partenzaText;
    private JTextField arrivoText;
    private JComboBox <Integer> yearComboBox;
    private JComboBox <Integer> dayComboBox;
    private JComboBox <Integer> monthComboBox;
    private JComboBox <String> tipoNatante;
    private JComboBox <Integer> hoursComboBox;
    private JComboBox <Integer> minComboBox;
    private JButton cercaButton;
    private JButton indietroButton;
    private JTable tableCorse;
    private JPanel PanelTabella;
    private JComboBox <Double> prezzoMin;
    private JButton prenotaButton;
    private JLabel MessaggioErroreSelezione;
    private JButton visualizzaPrenotazioniEffettuateButton;
    private JLabel telefonoLabel;
    private JLabel mailLabel;
    private JLabel sitoWebLabel;
    private JLabel indirizziSocialLabel;
    private JLabel contattiCompagniaLabel;
    private JPanel contatti;

    /**
     * JFrame per la finestra della pagina utente.
     */
    public JFrame frame7 = new JFrame("Tabellone Corse");
    /**
     * Il controller utilizzato per interagire con la logica di business.
     */
    public Controller controller;
    /**
     * Il frame chiamante.
     */
    public JFrame frameChiamante;

    /**
     * Costruttore della classe PaginaUtenteIntero.
     *
     * @param controller     il controller per gestire le operazioni logiche
     * @param frameChiamante il frame chiamante
     * @param idPasseggero   l'ID del passeggero
     */
    public PaginaUtenteIntero(Controller controller, JFrame frameChiamante, int idPasseggero) {
        this.controller = controller;
        frame7 = new JFrame("Pagina Utente");
        frame7.setContentPane(paginaUtenteIntero);
        frame7.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame7.pack();
        frame7.setVisible(true);
        frame7.setSize(800, 500);

        DefaultTableModel model = new DefaultTableModel(new Object[][]{}, new String[]{
                "ID CORSA", "CITTA PARTENZA", "CITTA ARRIVO", "SCALO", "RITARDO", "TIPO NATANTE", "DATA", "ORA", "PREZZO *", "POSTI RIMANENTI", "POSTI AUTO"
        }) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableCorse.setModel(model);
        tableCorse.setRowHeight(50);
        PanelTabella.setLayout(new BorderLayout());
        PanelTabella.add(new JScrollPane(tableCorse), BorderLayout.CENTER);

        String defaultValue = null; // Nessun valore predefinito selezionato

        Calendar cal = Calendar.getInstance();
        Integer currentYear = cal.get(Calendar.YEAR);
        for (Integer year = currentYear; year >= currentYear - 100; year--) {
            yearComboBox.addItem(year);
        }
        yearComboBox.setSelectedItem(defaultValue);

        for (Integer month = 1; month <= 12; month++) {
            monthComboBox.addItem(month);
        }
        monthComboBox.setSelectedItem(defaultValue);

        for (Integer day = 1; day <= 31; day++) {
            dayComboBox.addItem(day);
        }
        dayComboBox.setSelectedItem(defaultValue);

        String[] options = {"traghetto", "aliscafo", "motonave", "altro"};
        for (String option : options) {
            tipoNatante.addItem(option);
        }
        tipoNatante.setSelectedItem(defaultValue);

        for (int hour = 0; hour < 24; hour++) {
            hoursComboBox.addItem(hour);
        }

        for (int min = 0; min < 60; min++) {
            minComboBox.addItem(min);
        }

        Double[] valori = {0.0, 5.0, 10.0, 15.0, 20.0};
        for (Double option : valori) {
            prezzoMin.addItem(option);
        }

        try {
            ArrayList<String[]> corseComplete = controller.stampaCorseTabella();
            aggiornaTabella(model, corseComplete);

        } catch(SQLException e) {
            throw new RuntimeException(e);
        }

        indietroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame7.setVisible(false);
                frameChiamante.setVisible(true);
            }
        });

        cercaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String cittaP = partenzaText.getText().trim();
                String cittaA= arrivoText.getText().trim();
                String natante = (String)tipoNatante.getSelectedItem();
                Date giorno = getSelectedDate();
                Time orario = getSelectedTime();
                double prezzo = (double)prezzoMin.getSelectedItem();

                try {
                    ArrayList<String[]> corsa = controller.cercaCorse(cittaP, cittaA, natante, giorno, orario, prezzo);
                    aggiornaTabella(model, corsa);

                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }

            }
        });

        prenotaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = tableCorse.getSelectedRow();
                if (selectedRow != -1) {

                    int idCorsa = Integer.parseInt((String) tableCorse.getValueAt(selectedRow, 0));

                    PrenotazioneCorsa prenotazioneCorsa = new PrenotazioneCorsa(controller, frame7, idPasseggero, idCorsa);
                    frame7.setVisible(true);
                    prenotazioneCorsa.framePrenotazione.setVisible(true);

                } else {
                    MessaggioErroreSelezione.setText("Nessuna riga selezionata.");
                }
            }
        });

        visualizzaPrenotazioniEffettuateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                VisualizzaPrenotazioni visualizzaPrenotazioni = new VisualizzaPrenotazioni(controller, frame7, idPasseggero);
                frame7.setVisible(true);
                visualizzaPrenotazioni.frameVisualizzaPrenotazioni.setVisible(true);
            }
        });

        tableCorse.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if(!e.getValueIsAdjusting()) {
                    int selectedRow = tableCorse.getSelectedRow();
                    if(selectedRow != -1) {
                        int idCorsa = Integer.parseInt((String) tableCorse.getValueAt(selectedRow, 0));

                        try{
                            String compagnia = controller.recuperaCompagnia(idCorsa);

                            String telefono = controller.recuperaTelefonoCompagnia(compagnia);
                            String email = controller.recuperaEmailCompagnia(compagnia);
                            String sitoWeb = controller.recuperaSitoWebCompagnia(compagnia);
                            ArrayList<String>  indirizzoSocial = controller.recuperaIndirizzoSocial(compagnia);

                            contattiCompagniaLabel.setText("Contatti della compagnia: ");
                            telefonoLabel.setText("Telefono: " + telefono);
                            mailLabel.setText("Email: " + email);
                            sitoWebLabel.setText("Sito Web: " + sitoWeb);

                            StringBuilder indirizziSocialText = new StringBuilder("Indirizzi Social: ");
                            for (String indirizzo : indirizzoSocial) {
                                indirizziSocialText.append(indirizzo).append(", ");
                            }
                            // Rimuovi l'ultima virgola aggiunta in eccesso
                            if (indirizziSocialText.length() > 0) {
                                indirizziSocialText.deleteCharAt(indirizziSocialText.length() - 2);
                            }
                            indirizziSocialLabel.setText(indirizziSocialText.toString());

                        } catch (SQLException ex) {
                            throw new RuntimeException(ex);
                        }

                    }
                }
            }
        });

    }

    /**
     * Ottiene la data selezionata dall'utente dalle JComboBox.
     *
     * @return Oggetto Date rappresentante la data selezionata
     */
    private Date getSelectedDate() {
        Integer defaultValue = null;
        Integer year = (Integer) yearComboBox.getSelectedItem();
        Integer month = (Integer) monthComboBox.getSelectedItem();
        Integer day = (Integer) dayComboBox.getSelectedItem();

        if (year == null || month == null || day == null) {
            return null;
        }

        // Crea un oggetto Calendar e imposta l'anno, il mese e il giorno
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month - 1); // I mesi in Java Calendar iniziano da 0
        cal.set(Calendar.DAY_OF_MONTH, day);

        yearComboBox.setSelectedItem(defaultValue);
        monthComboBox.setSelectedItem(defaultValue);
        dayComboBox.setSelectedItem(defaultValue);

        return cal.getTime();
    }
    /**
     * Ottiene l'ora selezionata dall'utente dalle JComboBox.
     *
     * @return Oggetto Time rappresentante l'ora selezionata
     */
    private Time getSelectedTime() {
        int hour = (int) hoursComboBox.getSelectedItem();
        int min = (int) minComboBox.getSelectedItem();

        return new Time(hour, min, 0);
    }

    /**
     * Aggiorna il modello della tabella con i dati delle corse forniti.
     *
     * @param model Il modello della tabella da aggiornare
     * @param corsa ArrayList contenente i dati delle corse
     */
    private void aggiornaTabella(DefaultTableModel model, ArrayList<String[]> corsa) {
        model.setRowCount(0); // Rimuove tutte le righe attualmente presenti nel modello
        int indiceRitardo = 4;
        int indiceScalo = 3;
        for (int i = 0; i < corsa.size(); i++) {

            String[] rowData = corsa.get(i);
            String ritardo = rowData[indiceRitardo];
            if (ritardo == null || ritardo.isEmpty() || ritardo.equals("null")) {
                rowData[indiceRitardo] = "Nessun ritardo";
            }
            String scalo = rowData[indiceScalo];
            if (scalo == null || scalo.isEmpty() || scalo.equals("null")) {
                rowData[indiceScalo] = "Nessuno scalo";
            }
            model.addRow(rowData);
        }
    }
}
