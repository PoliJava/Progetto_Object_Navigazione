package Progetto.GUI;

import java.util.ArrayList;

/**
 * Rappresenta un passeggero che può effettuare prenotazioni e possiede biglietti.
 */
public class Passeggero {
    /**
     * Il nome del passeggero.
     */
    public String nome;
    /**
     * Il cognome del passeggero.
     */
    public String cognome;
    /**
     * La data di nascita del passeggero.
     */
    public String dataNascita;

    /**
     * Le prenotazioni effettuate dal passeggero.
     */
    ArrayList<Prenotazione> prenotazione;
    /**
     * I biglietti posseduti dal passeggero.
     */
    ArrayList<BigliettoIntero> biglietto;

    /**
     * Costruisce una nuova istanza di Passeggero con i dati specificati e associa la prenotazione e
     * il biglietto forniti.
     *
     * @param nome        il nome del passeggero
     * @param cognome     il cognome del passeggero
     * @param dataNascita la data di nascita del passeggero
     * @param pren        la prenotazione associata al passeggero
     * @param bI          il biglietto associato al passeggero
     */
    public Passeggero(String nome, String cognome, String dataNascita, Prenotazione pren, BigliettoIntero bI) {
        this.nome = nome;
        this.cognome = cognome;
        this.dataNascita = dataNascita;
        prenotazione.add(pren);
        biglietto.add(bI);
    }
}
