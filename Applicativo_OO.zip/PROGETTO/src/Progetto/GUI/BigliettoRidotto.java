package Progetto.GUI;

/**
 * Rappresenta un biglietto ridotto utilizzato per agevolazioni.
 */
public class BigliettoRidotto {
    /**
     * Il prezzo del biglietto ridotto.
     */
    public float prezzo;
    /**
     * Il nominativo associato al biglietto ridotto.
     */
    public String nominativo;
    /**
     * Il passeggero associato al biglietto ridotto.
     */
    Passeggero passeggero;
    /**
     * La prenotazione relativa al biglietto ridotto.
     */
    Prenotazione prenotazione;


    /**
     * Costruttore di biglietto ridotto con il nominativo, il prezzo, il passeggero e la prenotazione specificati.
     *
     * @param nominativo il nominativo associato al biglietto
     * @param prezzo     il prezzo del biglietto
     * @param p          il passeggero associato al biglietto
     * @param pre        la prenotazione relativa al biglietto
     */
    public BigliettoRidotto(String nominativo, float prezzo, Passeggero p, Prenotazione pre)
    {
        this.nominativo = nominativo;
        this.prezzo=prezzo;
        passeggero = p;
        prenotazione = pre;
    }

}
