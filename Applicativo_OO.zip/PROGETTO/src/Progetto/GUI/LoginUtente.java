package Progetto.GUI;

import Progetto.GUI.Controller.Controller;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

/**
 * Questa classe rappresenta la pagina di accesso dell'utente.
 */
public class LoginUtente extends JFrame{
    private JPanel Accesso;
    private JButton accediButton;
    private JTextField nomeText;
    private JTextField cognomeText;
    private JButton indietroButton;
    private JLabel MessaggioAccesso;

    /**
     * Il controller per gestire le azioni dell'utente.
     */
    public Controller controller;
    private JComboBox <Integer> yearComboBox;
    private JComboBox <Integer> dayComboBox;
    private JComboBox <Integer> monthComboBox;
    private JPanel inserimentoNome;
    private JPanel inserimentoCognome;
    private JPanel accedi;
    private JPanel inserimentoDataNascita;
    /**
     * Il frame per la pagina di accesso.
     */
    public static JFrame frame5 = new JFrame("Login Utente");


    /**
     * Costruisce una nuova istanza di LoginUtente.
     *
     * @param controller     il controller per gestire le azioni dell'utente
     * @param frameChiamante il frame chiamante
     */
    public LoginUtente(Controller controller, JFrame frameChiamante){

        this.controller=controller;
        frame5 = new JFrame("Pagina di accesso");
        frame5.setContentPane(Accesso);
        frame5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame5.pack();
        frame5.setVisible(true);
        frame5.setSize(800, 500);

        Calendar cal = Calendar.getInstance();
        int currentYear = cal.get(Calendar.YEAR);
        for (int year = currentYear; year >= currentYear - 100; year--) {
            yearComboBox.addItem(year);
        }

        for (int month = 1; month <= 12; month++) {
            monthComboBox.addItem(month);
        }

        for (int day = 1; day <= 31; day++) {
            dayComboBox.addItem(day);
        }

        indietroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame5.setVisible(false);
                frameChiamante.setVisible(true);
            }
        });

        accediButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String firstName = nomeText.getText();
                String lastName = cognomeText.getText();
                Date birthDate = getSelectedDate();

                try {
                    if (controller.verificaUtente(firstName, lastName, birthDate)== true) {

                        int idPasseggero = controller.cercaIdPasseggero(firstName, lastName, birthDate);

                        PaginaUtenteIntero paginaUtenteIntero = new PaginaUtenteIntero(controller, frame5, idPasseggero);
                        frame5.setVisible(false);
                        paginaUtenteIntero.frame7.setVisible(true);

                    } else {

                        MessaggioAccesso.setText("I dati inseriti non sono corretti, si prega di riprovare o registrarsi");
                    }



                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }

            }
        });
    }

    private Date getSelectedDate() {
        // Ottieni la data selezionata dalle JComboBox
        int year = (int) yearComboBox.getSelectedItem();
        int month = (int) monthComboBox.getSelectedItem();
        int day = (int) dayComboBox.getSelectedItem();

        // Crea un oggetto Calendar e imposta l'anno, il mese e il giorno
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, month - 1); // I mesi in Java Calendar iniziano da 0
        cal.set(Calendar.DAY_OF_MONTH, day);

        // Restituisci la data come oggetto Date
        return cal.getTime();
    }


}
